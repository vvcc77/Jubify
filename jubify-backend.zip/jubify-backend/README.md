# JUBIFY Backend

Backend modular, tipado y demo-first para JUBIFY.

## Qué trae

- Fastify + TypeScript
- Validación estricta con Zod
- Arquitectura modular simple
- Repositorios in-memory listos para demo
- Session auth simple para prototipo
- Event log / audit trail
- Dashboard consolidado
- Adapters mock y reales para Avalanche y GenLayer
- Modo degradado elegante si las integraciones fallan

## Filosofía

Esto levanta **sin base externa**.  
La persistencia por defecto es en memoria para no matar la demo.  
La siguiente capa natural es agregar PostgreSQL/Prisma sin romper contratos ni servicios.

## Requisitos

- Node.js 22+
- npm 10+

## Instalación

```bash
npm install
cp .env.example .env
npm run dev
```

Servidor por defecto en:

```txt
http://localhost:3001
```

## Scripts

```bash
npm run dev
npm run build
npm run start
npm run check
```

## Modos de integración

- `mock`: usa siempre providers mock.
- `hybrid`: intenta provider real y si falla, cae a mock.
- `real`: intenta provider real; si falla, responde con degradación y último fallback disponible.

## Flujo mínimo de prueba

### 1) Login demo

```bash
curl -X POST http://localhost:3001/auth/demo-login \
  -H "content-type: application/json" \
  -d '{"demoUser":"default"}'
```

Guarda `accessToken`.

### 2) Consultar onboarding

```bash
curl http://localhost:3001/onboarding/state \
  -H "authorization: Bearer TU_TOKEN"
```

### 3) Ver dashboard

```bash
curl http://localhost:3001/dashboard/usr_demo_001 \
  -H "authorization: Bearer TU_TOKEN"
```

## Variables importantes

### Core
- `APP_MODE=demo`
- `INTEGRATION_MODE=mock|hybrid|real`

### Avalanche
- `AVALANCHE_RPC_URL`
- `AVALANCHE_CHAIN_ID`
- `AVALANCHE_VAULT_ADDRESS`

### GenLayer
- `GENLAYER_API_URL`
- `GENLAYER_FROM_ADDRESS`
- `GENLAYER_CONTRACT_ADDRESS`
- `GENLAYER_PROTECTION_CALL_DATA`
- `GENLAYER_RETIREMENT_CALL_DATA`
- `GENLAYER_PROOF_OF_LIFE_CALL_DATA`

## Notas sobre GenLayer real

El adapter real usa:
- `GET /health` para health,
- y JSON-RPC `gen_call` cuando hay `contract address`, `from address` y `call data` configurados.

Mientras esos hex payloads no estén definidos, el backend sigue funcionando y cae elegantemente al mock. Exactamente como debe ser una demo con autoestima.

## Estructura

```txt
src/
  config/
  domain/
  infra/
  modules/
  shared/
  types/
```

## Endpoints

### Auth
- `POST /auth/demo-login`
- `POST /auth/email-login`
- `POST /auth/wallet-connect`

### Onboarding / Profile
- `GET /onboarding/state`
- `POST /onboarding/profile`
- `POST /onboarding/preferences`

### Plan
- `POST /plan`
- `GET /plan/:userId`
- `PATCH /plan/:userId/contribution`

### Retirement
- `POST /plan/:userId/retirement`
- `GET /plan/:userId/retirement`

### Protection / Inheritance
- `POST /plan/:userId/protection`
- `POST /plan/:userId/inheritance`
- `GET /plan/:userId/inheritance`

### Events
- `GET /plan/:userId/events`

### Dashboard
- `GET /dashboard/:userId`

### Health / Integrations
- `GET /health`
- `GET /integrations/status`

## Siguiente paso lógico

1. levantar esto,
2. conectar frontend,
3. congelar contratos,
4. recién ahí meter Prisma/PostgreSQL,
5. después adapters reales con ABI/contract payloads definitivos.
