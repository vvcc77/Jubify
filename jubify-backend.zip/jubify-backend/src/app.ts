import Fastify from 'fastify';
import { buildContainer } from './container';
import { errorHandler } from './shared/errors/error-handler';
import { authRoutes } from './modules/auth/auth.routes';
import { onboardingRoutes } from './modules/onboarding/onboarding.routes';
import { planRoutes } from './modules/plan/plan.routes';
import { retirementRoutes } from './modules/retirement/retirement.routes';
import { protectionRoutes } from './modules/protection/protection.routes';
import { eventsRoutes } from './modules/events/events.routes';
import { dashboardRoutes } from './modules/dashboard/dashboard.routes';
import { integrationsRoutes } from './modules/integrations/integrations.routes';

export async function buildApp() {
  const app = Fastify({
    logger: true,
    trustProxy: true
  });

  const container = buildContainer();
  app.decorate('container', container);

  app.setErrorHandler(errorHandler);

  app.get('/', async () => ({
    app: 'jubify-backend',
    status: 'up'
  }));

  await authRoutes(app);
  await onboardingRoutes(app);
  await planRoutes(app);
  await retirementRoutes(app);
  await protectionRoutes(app);
  await eventsRoutes(app);
  await dashboardRoutes(app);
  await integrationsRoutes(app);

  return app;
}
