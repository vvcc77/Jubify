import type { IntegrationState } from '../../domain/models';
import { BeneficiaryRepository, IntegrationStateRepository, PlanRepository, ProfileRepository, ProtectionRepository, RetirementRepository } from '../../infra/memory/repositories';
import { AppError } from '../../shared/errors/app-error';
import { nextContributionAt, nextReleaseAt, nowIso } from '../../shared/utils/dates';
import { AuthService } from '../auth/auth.service';
import { EventsService } from '../events/events.service';
import { IntegrationsService } from '../integrations/integrations.service';

export class DashboardService {
  constructor(
    private readonly authService: AuthService,
    private readonly profileRepo: ProfileRepository,
    private readonly planRepo: PlanRepository,
    private readonly retirementRepo: RetirementRepository,
    private readonly protectionRepo: ProtectionRepository,
    private readonly beneficiaryRepo: BeneficiaryRepository,
    private readonly integrationStateRepo: IntegrationStateRepository,
    private readonly eventsService: EventsService,
    private readonly integrationsService: IntegrationsService
  ) {}

  async getDashboard(userId: string) {
    const user = this.authService.getUser(userId);
    const profile = this.profileRepo.findByUserId(userId);
    const plan = this.planRepo.findByUserId(userId);
    const retirement = this.retirementRepo.findByUserId(userId);
    const protection = this.protectionRepo.findByUserId(userId);
    const beneficiaries = this.beneficiaryRepo.findByUserId(userId);

    if (!plan) {
      throw AppError.notFound('Dashboard unavailable because plan is missing');
    }

    const balance = await this.integrationsService.getVaultSummary(user);
    await this.integrationsService.getStatuses();

    const states = this.integrationStateRepo.list().reduce<Record<string, IntegrationState['status']>>((acc, item) => {
      acc[item.provider] = item.status;
      return acc;
    }, {});

    const proofOfLife = await this.integrationsService.getGenLayerProofOfLife(user);
    const retirementGuidance = await this.integrationsService.getGenLayerRetirementGuidance(user);

    return {
      user: {
        id: user.id,
        authType: user.authType,
        email: user.email,
        wallet: user.wallet
      },
      profile: profile ?? null,
      plan,
      balance,
      nextContribution: {
        dueAt: nextContributionAt(plan.updatedAt ?? nowIso(), plan.contributionFrequency),
        amount: plan.contributionAmount,
        currency: plan.currency
      },
      retirement: retirement
        ? {
            configured: true,
            mode: retirement.mode,
            releaseFrequency: retirement.releaseFrequency,
            nextReleaseAt: nextReleaseAt(retirement.updatedAt ?? nowIso(), retirement.releaseFrequency),
            guidance: retirementGuidance
          }
        : {
            configured: false
          },
      inheritance: {
        configured: Boolean(protection?.inheritanceEnabled),
        beneficiariesCount: beneficiaries.length
      },
      protection: protection
        ? {
            protectionEnabled: protection.protectionEnabled,
            proofOfLifeInterval: protection.proofOfLifeInterval,
            proofOfLife
          }
        : null,
      integrations: {
        avalanche: states.avalanche ?? 'offline',
        genlayer: states.genlayer ?? 'offline'
      },
      upcomingEvents: [
        {
          type: 'next_contribution',
          at: nextContributionAt(plan.updatedAt ?? nowIso(), plan.contributionFrequency)
        },
        retirement
          ? {
              type: 'next_release',
              at: nextReleaseAt(retirement.updatedAt ?? nowIso(), retirement.releaseFrequency)
            }
          : null
      ].filter(Boolean),
      timeline: this.eventsService.list(userId, 8)
    };
  }
}
