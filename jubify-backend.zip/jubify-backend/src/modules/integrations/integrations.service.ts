import type {
  IntegrationHealth,
  IntegrationProvider,
  IntegrationState,
  User,
  VaultSummary
} from '../../domain/models';
import { IntegrationStateRepository } from '../../infra/memory/repositories';
import { nowIso } from '../../shared/utils/dates';
import { EventsService } from '../events/events.service';
import type { IntelligentContractPort } from './ports/intelligent-contract.port';
import type { VaultProviderPort } from './ports/vault-provider.port';

type IntegrationMode = 'mock' | 'hybrid' | 'real';

export class IntegrationsService {
  constructor(
    private readonly mode: IntegrationMode,
    private readonly stateRepo: IntegrationStateRepository,
    private readonly eventsService: EventsService,
    private readonly realVaultProvider: VaultProviderPort,
    private readonly mockVaultProvider: VaultProviderPort,
    private readonly realGenLayerProvider: IntelligentContractPort,
    private readonly mockGenLayerProvider: IntelligentContractPort
  ) {}

  async getStatuses(): Promise<IntegrationState[]> {
    const avalanche = await this.safeHealth('avalanche');
    const genlayer = await this.safeHealth('genlayer');
    return [avalanche, genlayer];
  }

  async getVaultSummary(user: User): Promise<VaultSummary> {
    if (this.mode === 'mock') {
      const mock = await this.mockVaultProvider.getVaultSummary(user);
      this.persistState('avalanche', 'healthy', 'Mock mode enabled', user.id, 'mock');
      return mock;
    }

    try {
      const real = await this.realVaultProvider.getVaultSummary(user);
      this.persistState('avalanche', 'healthy', real.providerMessage ?? 'Live vault summary', user.id, 'avalanche');
      return real;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown Avalanche error';
      this.persistState('avalanche', this.mode === 'real' ? 'degraded' : 'degraded', message, user.id, 'avalanche');

      const mock = await this.mockVaultProvider.getVaultSummary(user);
      return {
        ...mock,
        providerStatus: 'degraded',
        providerMessage: `Fallback active: ${message}`
      };
    }
  }

  async getGenLayerProtectionDecision(user: User) {
    if (this.mode === 'mock') {
      return this.mockGenLayerProvider.getProtectionDecision(user);
    }

    try {
      const result = await this.realGenLayerProvider.getProtectionDecision(user);
      this.persistState('genlayer', 'healthy', 'Live intelligent contract reachable', user.id, 'genlayer');
      return result;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown GenLayer error';
      this.persistState('genlayer', 'degraded', message, user.id, 'genlayer');
      return this.mockGenLayerProvider.getProtectionDecision(user);
    }
  }

  async getGenLayerRetirementGuidance(user: User) {
    if (this.mode === 'mock') {
      return this.mockGenLayerProvider.getRetirementRecommendation(user);
    }

    try {
      const result = await this.realGenLayerProvider.getRetirementRecommendation(user);
      this.persistState('genlayer', 'healthy', 'Live intelligent contract reachable', user.id, 'genlayer');
      return result;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown GenLayer error';
      this.persistState('genlayer', 'degraded', message, user.id, 'genlayer');
      return this.mockGenLayerProvider.getRetirementRecommendation(user);
    }
  }

  async getGenLayerProofOfLife(user: User) {
    if (this.mode === 'mock') {
      return this.mockGenLayerProvider.simulateProofOfLifeCheck(user);
    }

    try {
      const result = await this.realGenLayerProvider.simulateProofOfLifeCheck(user);
      this.persistState('genlayer', 'healthy', 'Live intelligent contract reachable', user.id, 'genlayer');
      return result;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown GenLayer error';
      this.persistState('genlayer', 'degraded', message, user.id, 'genlayer');
      return this.mockGenLayerProvider.simulateProofOfLifeCheck(user);
    }
  }

  private async safeHealth(provider: IntegrationProvider): Promise<IntegrationState> {
    if (this.mode === 'mock') {
      const state: IntegrationState = {
        provider,
        status: 'healthy',
        lastSync: nowIso(),
        message: 'Mock mode enabled'
      };
      this.stateRepo.upsert(state);
      return state;
    }

    try {
      const health: IntegrationHealth =
        provider === 'avalanche'
          ? await this.realVaultProvider.getHealth()
          : await this.realGenLayerProvider.getHealth();

      const state: IntegrationState = {
        provider,
        status: health.status,
        lastSync: health.checkedAt,
        message: health.message
      };

      this.stateRepo.upsert(state);
      return state;
    } catch (error) {
      const message = error instanceof Error ? error.message : `Unknown ${provider} error`;

      const state: IntegrationState = {
        provider,
        status: 'degraded',
        lastSync: nowIso(),
        message: this.mode === 'real'
          ? message
          : `Fallback available: ${message}`
      };

      this.stateRepo.upsert(state);
      return state;
    }
  }

  private persistState(
    provider: IntegrationProvider,
    status: 'healthy' | 'degraded' | 'offline',
    message: string,
    userId: string,
    source: 'mock' | 'avalanche' | 'genlayer'
  ): void {
    this.stateRepo.upsert({
      provider,
      status,
      lastSync: nowIso(),
      message
    });

    this.eventsService.record(userId, 'external_sync_status', {
      provider,
      status,
      message
    }, source);
  }
}
