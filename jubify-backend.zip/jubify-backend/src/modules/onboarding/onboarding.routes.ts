import type { FastifyInstance } from 'fastify';
import { ok } from '../../shared/http/response';
import { parseWithSchema } from '../../shared/http/validation';
import { requireAuth } from '../../shared/http/auth-guard';
import { preferencesSchema, profileSchema } from './onboarding.schemas';

export async function onboardingRoutes(app: FastifyInstance): Promise<void> {
  app.get('/onboarding/state', { preHandler: requireAuth }, async (request, reply) => {
    const state = app.container.onboardingService.getState(request.auth!.userId);
    ok(request, reply, state, { mode: app.container.env.INTEGRATION_MODE });
  });

  app.post('/onboarding/profile', { preHandler: requireAuth }, async (request, reply) => {
    const body = parseWithSchema(profileSchema, request.body);
    const profile = app.container.profileService.saveProfile(request.auth!.userId, body);
    ok(request, reply, { profile }, { mode: app.container.env.INTEGRATION_MODE });
  });

  app.post('/onboarding/preferences', { preHandler: requireAuth }, async (request, reply) => {
    const body = parseWithSchema(preferencesSchema, request.body);
    const profile = app.container.profileService.savePreferences(request.auth!.userId, body.preferences);
    ok(request, reply, { profile }, { mode: app.container.env.INTEGRATION_MODE });
  });
}
