import type { FastifyInstance } from 'fastify';
import { assertUserAccess, requireAuth } from '../../shared/http/auth-guard';
import { ok } from '../../shared/http/response';
import { parseWithSchema } from '../../shared/http/validation';
import { userIdParamsSchema } from '../plan/plan.schemas';
import { retirementSchema } from './retirement.schemas';

export async function retirementRoutes(app: FastifyInstance): Promise<void> {
  app.post('/plan/:userId/retirement', { preHandler: requireAuth }, async (request, reply) => {
    const params = parseWithSchema(userIdParamsSchema, request.params);
    const body = parseWithSchema(retirementSchema, request.body);
    assertUserAccess(request, params.userId);
    const retirement = app.container.retirementService.configure(params.userId, body);
    ok(request, reply, { retirement }, { mode: app.container.env.INTEGRATION_MODE });
  });

  app.get('/plan/:userId/retirement', { preHandler: requireAuth }, async (request, reply) => {
    const params = parseWithSchema(userIdParamsSchema, request.params);
    assertUserAccess(request, params.userId);
    const retirement = app.container.retirementService.getByUserId(params.userId);
    ok(request, reply, { retirement }, { mode: app.container.env.INTEGRATION_MODE });
  });
}
