import type { AppContainer } from './container';
import { nowIso } from './shared/utils/dates';

export function seedDemo(container: AppContainer): void {
  const userRepo = container.userRepo;
  const profileRepo = container.profileRepo;
  const planRepo = container.planRepo;
  const retirementRepo = container.retirementRepo;
  const protectionRepo = container.protectionRepo;
  const beneficiaryRepo = container.beneficiaryRepo;
  const integrationStateRepo = container.integrationStateRepo;
  const events = container.eventsService;

  if (!userRepo.findById('usr_demo_001')) {
    userRepo.upsert({
      id: 'usr_demo_001',
      authType: 'demo',
      email: 'demo@jubify.app',
      createdAt: nowIso(),
      updatedAt: nowIso()
    });
  }

  profileRepo.save({
    userId: 'usr_demo_001',
    riskTolerance: 'moderate',
    timeHorizon: '15y',
    preferences: ['capital_preservation', 'simple_withdrawals'],
    createdAt: nowIso(),
    updatedAt: nowIso()
  });

  planRepo.save({
    id: 'plan_demo_001',
    userId: 'usr_demo_001',
    status: 'active',
    contributionAmount: 100,
    contributionFrequency: 'monthly',
    currency: 'USD',
    strategyType: 'balanced',
    createdAt: nowIso(),
    updatedAt: nowIso()
  });

  retirementRepo.save({
    userId: 'usr_demo_001',
    mode: 'scheduled_income',
    lockPeriod: '10y',
    releaseFrequency: 'monthly',
    estimatedProjection: {
      label: 'demo_projection',
      value: 250
    },
    createdAt: nowIso(),
    updatedAt: nowIso()
  });

  protectionRepo.save({
    userId: 'usr_demo_001',
    protectionEnabled: true,
    inheritanceEnabled: true,
    proofOfLifeInterval: '90d',
    createdAt: nowIso(),
    updatedAt: nowIso()
  });

  beneficiaryRepo.replaceForUser('usr_demo_001', [
    {
      id: 'bnf_demo_001',
      userId: 'usr_demo_001',
      name: 'Jane Doe',
      destinationWalletOrAccount: '0xDEMO1234567890',
      percentage: 100,
      createdAt: nowIso(),
      updatedAt: nowIso()
    }
  ]);

  integrationStateRepo.upsert({
    provider: 'avalanche',
    status: 'healthy',
    lastSync: nowIso(),
    message: 'Seeded mock state'
  });

  integrationStateRepo.upsert({
    provider: 'genlayer',
    status: 'healthy',
    lastSync: nowIso(),
    message: 'Seeded mock state'
  });

  events.record('usr_demo_001', 'plan_created', {
    contributionAmount: 100,
    contributionFrequency: 'monthly',
    currency: 'USD',
    strategyType: 'balanced'
  }, 'system');

  events.record('usr_demo_001', 'retirement_configured', {
    mode: 'scheduled_income',
    releaseFrequency: 'monthly'
  }, 'system');

  events.record('usr_demo_001', 'protection_enabled', {
    protectionEnabled: true,
    inheritanceEnabled: true
  }, 'system');

  events.record('usr_demo_001', 'inheritance_updated', {
    beneficiariesCount: 1
  }, 'system');
}
