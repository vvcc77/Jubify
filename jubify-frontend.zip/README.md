
  # Decentralized Pension Fund Webapp

  This is a code bundle for Decentralized Pension Fund Webapp. The original project is available at https://www.figma.com/design/sRvqyA73gkpNzc0sYd16jg/Decentralized-Pension-Fund-Webapp.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  