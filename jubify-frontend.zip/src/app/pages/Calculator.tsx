import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { ChevronDown, Info } from 'lucide-react';
import { AskGuideButton } from '../components/AskGuideButton';

export default function Calculator() {
  const navigate = useNavigate();
  const [retirementAge, setRetirementAge] = useState(67);
  const [retirementMonths, setRetirementMonths] = useState(3);
  const [currentAge, setCurrentAge] = useState(35);
  const [currentSalary, setCurrentSalary] = useState(45000);
  const [monthlyContribution, setMonthlyContribution] = useState(500);
  const [hasPartner, setHasPartner] = useState(false);
  const [higherPensionYears, setHigherPensionYears] = useState('none');
  const [showMoreInfo, setShowMoreInfo] = useState(false);
  
  // Calculate pension estimates
  const yearsToRetirement = retirementAge - currentAge;
  const totalContributions = monthlyContribution * 12 * yearsToRetirement;
  const estimatedGrowth = totalContributions * 1.65; // Simplified 8.2% annual growth estimate
  const expectedYieldRate = 8.2; // Annual yield percentage
  const monthlyPensionAOW = 762;
  const monthlyPensionTotal = Math.round(estimatedGrowth / (12 * 20)); // Simplified: divide by 20 years
  const partnerPension = hasPartner ? 1282 : 0;

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const totalMonths = parseInt(e.target.value);
    const years = Math.floor(totalMonths / 12);
    const months = totalMonths % 12;
    setRetirementAge(years);
    setRetirementMonths(months);
  };

  const handleContinue = () => {
    navigate('/insurance');
  };

  return (
    <div className="max-w-6xl mx-auto px-8 py-12">
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 bg-teal-700 text-white rounded-full flex items-center justify-center text-sm">1</div>
          <div className="w-8 h-8 bg-slate-200 text-slate-600 rounded-full flex items-center justify-center text-sm">2</div>
          <div className="w-8 h-8 bg-slate-200 text-slate-600 rounded-full flex items-center justify-center text-sm">3</div>
          <div className="w-8 h-8 bg-slate-200 text-slate-600 rounded-full flex items-center justify-center text-sm">4</div>
        </div>
        <h1 className="text-3xl text-teal-900">Plan Your Future</h1>
        <p className="text-slate-600 mt-2">Let's calculate your retirement plan</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          {/* Current Information */}
          <div className="bg-gradient-to-br from-blue-50 to-teal-50 rounded-2xl p-8 mx-[0px] mt-[0px] mb-[12px]">
            <h2 className="text-teal-900 text-xl mb-6">What about you?</h2>
            
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div>
                <label className="block text-teal-900 mb-2">How old are you?</label>
                <input
                  type="number"
                  value={currentAge}
                  onChange={(e) => setCurrentAge(parseInt(e.target.value))}
                  className="w-full px-4 py-3 rounded-xl border border-teal-200 bg-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>
              <div>
                <label className="block text-teal-900 mb-2">How much do you earn per month?</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600">$</span>
                  <input
                    type="number"
                    value={currentSalary}
                    onChange={(e) => setCurrentSalary(parseInt(e.target.value))}
                    className="w-full pl-8 pr-4 py-3 rounded-xl border border-teal-200 bg-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-teal-900 mb-2">How much can you save per month?</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600">$</span>
                <input
                  type="number"
                  value={monthlyContribution}
                  onChange={(e) => setMonthlyContribution(parseInt(e.target.value))}
                  className="w-full pl-8 pr-4 py-3 rounded-xl border border-teal-200 bg-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>
            </div>

            <div className="flex items-center gap-3">
              
              
            </div>
          </div>

          {/* Retirement Age */}
          <div className="bg-gradient-to-br from-blue-50 to-teal-50 rounded-2xl p-8">
            <h2 className="text-teal-900 text-xl mb-2">When do you want to retire?</h2>
            <p className="text-slate-600 mb-6">I want to retire at:</p>
            
            <div className="bg-white rounded-2xl p-8">
              <div className="text-center mb-6">
                <div className="inline-block px-6 py-3 bg-slate-700 text-white rounded-full">
                  {retirementAge} years and {retirementMonths} months
                </div>
              </div>
              
              <div className="relative">
                <input
                  type="range"
                  min={55 * 12}
                  max={75 * 12}
                  value={retirementAge * 12 + retirementMonths}
                  onChange={handleSliderChange}
                  className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-teal-600"
                />
                <div className="flex justify-between mt-2">
                  <span className="text-slate-600 text-sm">55</span>
                  <span className="text-slate-600 text-sm">{retirementAge} years {retirementMonths} months</span>
                  <span className="text-slate-600 text-sm">75</span>
                </div>
                <div className="text-center mt-2">
                  <span className="text-teal-700 text-sm font-medium">{yearsToRetirement} years left</span>
                </div>
              </div>
            </div>

            <button 
              onClick={() => setShowMoreInfo(!showMoreInfo)}
              className="text-teal-700 text-sm mt-4 flex items-center gap-1 hover:underline"
            >
              More information about retirement age
              <ChevronDown className={`w-4 h-4 transition-transform ${showMoreInfo ? 'rotate-180' : ''}`} />
            </button>
          </div>

          {/* Higher Pension Option */}
          
        </div>

        {/* Summary Panel */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-2xl p-6 shadow-lg sticky top-8">
            <h3 className="text-teal-900 text-lg mb-6">My Retirement Plan</h3>
            
            <div className="space-y-6">
              <div>
                <p className="text-slate-600 text-sm mb-1">from {retirementAge} years and {retirementMonths} months</p>
                
                <p className="text-3xl text-teal-900">${monthlyPensionAOW}</p>
                <p className="text-slate-500 text-sm">net per month</p>
                <p className="text-teal-600 text-sm mt-1">Expected yield: {expectedYieldRate}%</p>
                <p className="text-slate-600 text-sm">{yearsToRetirement} years left to retire</p>
              </div>

              

              {hasPartner && (
                <div className="border-t border-slate-200 pt-6">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-8 h-8 bg-teal-700 rounded-full flex items-center justify-center">
                      <Info className="w-4 h-4 text-white" />
                    </div>
                    <p className="text-teal-900">Partner pension</p>
                  </div>
                  <p className="text-3xl text-teal-900">${partnerPension}</p>
                  <p className="text-slate-500 text-sm">gross per month</p>
                </div>
              )}
            </div>

            <div className="mt-8 space-y-3">
              <button 
                onClick={handleContinue}
                className="w-full px-6 py-3 bg-teal-700 text-white rounded-full hover:bg-teal-800 transition-colors"
              >
                Continue
              </button>
              <button className="w-full px-6 py-3 border-2 border-slate-300 text-slate-700 rounded-full hover:bg-slate-50 transition-colors flex items-center justify-center gap-2">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
                </svg>
                Print
              </button>
              <AskGuideButton />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}