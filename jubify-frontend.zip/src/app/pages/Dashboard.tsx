import { useState } from 'react';
import { Link } from 'react-router';
import { 
  TrendingUp, 
  Upload, 
  Edit3, 
  Pause, 
  Play, 
  Calendar,
  Brain,
  PieChart,
  FileText,
  Activity,
  Plus,
  Wallet
} from 'lucide-react';
import { LineChart, Line, PieChart as RePieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function Dashboard() {
  const [isPaused, setIsPaused] = useState(false);

  // Yearly projection data - 32 years until retirement
  const portfolioData = [
    { year: 'Now', current: 8100, expected: 8100 },
    { year: '5y', current: 42000, expected: 45000 },
    { year: '10y', current: 88000, expected: 98000 },
    { year: '15y', current: 142000, expected: 165000 },
    { year: '20y', current: 205000, expected: 248000 },
    { year: '25y', current: 278000, expected: 348000 },
    { year: '30y', current: 362000, expected: 465000 },
    { year: '32y', current: 395000, expected: 520000 },
  ];

  const allocationData = [
    { id: 'crypto', name: 'Crypto Assets', value: 35, color: '#0d9488' },
    { id: 'stocks', name: 'Stocks', value: 40, color: '#14b8a6' },
    { id: 'bonds', name: 'Bonds', value: 20, color: '#5eead4' },
    { id: 'stable', name: 'Stable Coins', value: 5, color: '#99f6e4' },
  ];

  const recentActivity = [
    { date: '2026-03-15', type: 'Contribution', amount: '€500', status: 'completed' },
    { date: '2026-03-10', type: 'Rebalancing', amount: '—', status: 'completed' },
    { date: '2026-02-15', type: 'Contribution', amount: '€500', status: 'completed' },
    { date: '2026-02-01', type: 'AI Optimization', amount: '—', status: 'completed' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-8 py-12">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-[Lato] text-[#00675f]">Welcome, Mark</h1>
          <p className="text-slate-600 mt-2">Manage your decentralized pension plan</p>
        </div>
        <div className="flex gap-3">
          
          <Link 
            to="/calculator"
            className="px-6 py-3 bg-teal-700 text-white rounded-full hover:bg-teal-800 transition-colors flex items-center gap-2 font-bold"
          >
            <Plus className="w-4 h-4" />
            Add Contribution
          </Link>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <div className="bg-gradient-to-br from-teal-500 to-teal-600 rounded-2xl p-6 text-white">
          <p className="text-teal-100 text-sm mb-2">Your Capital</p>
          <p className="text-3xl font-semibold mb-1">€8,100</p>
          <p className="text-teal-100 text-sm flex items-center gap-1">
            <TrendingUp className="w-4 h-4" />
            +8.2% this month
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-lg">
          <p className="text-slate-600 text-sm mb-2">Monthly Contribution</p>
          <p className="text-3xl text-teal-900 font-semibold mb-1">€500</p>
          <p className="text-slate-500 text-sm">Next due:<span className="font-bold"> April 1, 2026</span></p>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-lg">
          <p className="text-slate-600 text-sm mb-2">Expected Payouts</p>
          <p className="text-3xl text-teal-900 font-semibold mb-1">€2,237</p>
          <p className="text-slate-500 text-sm">per month at <span className="font-bold">67</span></p>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-lg">
          <p className="text-slate-600 text-sm mb-2">Years to Retirement</p>
          <p className="text-3xl text-teal-900 font-semibold mb-1">32</p>
          <p className="text-slate-500 text-sm">Until age <span className="font-bold">67</span></p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {/* Portfolio Growth Chart */}
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-teal-900 text-xl">Capital Growth</h2>
              <select className="px-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500">
                <option>Last 6 months</option>
                <option>Last year</option>
                <option>All time</option>
              </select>
            </div>
            <div className="mb-6 flex items-center gap-6">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-[#0d9488]"></div>
                <span className="text-sm text-slate-600">Current Portfolio</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-[#14b8a6]"></div>
                <span className="text-sm text-slate-600">Expected Growth</span>
              </div>
              <div className="text-sm text-slate-600">
                <span className="font-semibold text-teal-700">Expected Yield: 8.2%</span> annually
              </div>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={portfolioData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="year" stroke="#64748b" />
                <YAxis stroke="#64748b" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#fff', 
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px' 
                  }}
                  formatter={(value: number) => `$${value.toLocaleString()}`}
                />
                <Line 
                  type="monotone" 
                  dataKey="current" 
                  stroke="#0d9488" 
                  strokeWidth={3}
                  dot={{ fill: '#0d9488', r: 5 }}
                  name="Current"
                />
                <Line 
                  type="monotone" 
                  dataKey="expected" 
                  stroke="#5eead4" 
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={{ fill: '#5eead4', r: 4 }}
                  name="Expected"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Allocation */}
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-teal-900 text-xl mb-6">Asset Allocation</h2>
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <ResponsiveContainer width="100%" height={250}>
                <RePieChart>
                  <Pie
                    data={allocationData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {allocationData.map((entry, index) => (
                      <Cell key={`cell-${entry.id}-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </RePieChart>
              </ResponsiveContainer>
              <div className="space-y-3">
                {allocationData.map((item) => (
                  <div key={item.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-4 h-4 rounded-full" 
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="text-slate-700">{item.name}</span>
                    </div>
                    <span className="text-teal-900 font-semibold">{item.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-teal-900 text-xl mb-6">Recent Activity</h2>
            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div 
                  key={index}
                  className="flex items-center justify-between p-4 bg-slate-50 rounded-xl"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-teal-100 rounded-full flex items-center justify-center">
                      <Activity className="w-5 h-5 text-teal-700" />
                    </div>
                    <div>
                      <p className="text-teal-900 font-semibold">{activity.type}</p>
                      <p className="text-sm text-slate-600">{activity.date}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-teal-900 font-semibold">{activity.amount}</p>
                    <p className="text-sm text-green-600 capitalize">{activity.status}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Plan Controls */}
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <h3 className="text-teal-900 text-lg mb-4">Plan Controls</h3>
            <div className="space-y-3">
              <button
                onClick={() => setIsPaused(!isPaused)}
                className={`w-full px-4 py-3 rounded-xl flex items-center justify-center gap-2 transition-colors ${
                  isPaused
                    ? 'bg-green-600 text-white hover:bg-green-700'
                    : 'bg-amber-100 text-amber-800 hover:bg-amber-200'
                }`}
              >
                {isPaused ? (
                  <>
                    <Play className="w-5 h-5" />
                    Resume Plan
                  </>
                ) : (
                  <>
                    <Pause className="w-5 h-5" />
                    Pause Plan
                  </>
                )}
              </button>
              
              <Link
                to="/calculator"
                className="w-full px-4 py-3 bg-teal-700 text-white rounded-xl hover:bg-teal-800 transition-colors flex items-center justify-center gap-2"
              >
                <Edit3 className="w-5 h-5" />
                Edit Plan
              </Link>

              <button className="w-full px-4 py-3 border-2 border-slate-300 text-slate-700 rounded-xl hover:bg-slate-50 transition-colors flex items-center justify-center gap-2">
                <Calendar className="w-5 h-5" />
                View Schedule
              </button>
            </div>
          </div>

          {/* AI Insights */}
          <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-2xl p-6 border border-purple-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-purple-900 font-semibold">AI Steward</h3>
            </div>
            <p className="text-sm text-slate-700 mb-4">Your fund is performing excellently. Current growth rate is 8.2%, exceeding our 7.5% target.</p>
            <button className="w-full px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm">
              Ask AI a Question
            </button>
          </div>

          {/* Documents */}
          

          {/* Withdraw Link */}
          <div className="bg-gradient-to-br from-teal-50 to-blue-50 rounded-2xl p-6 border border-teal-200">
            <h3 className="text-teal-900 font-semibold mb-2">Ready to Retire?</h3>
            <p className="text-sm text-slate-600 mb-4">
              If you've reached retirement age, you can start withdrawing from your pension.
            </p>
            <Link
              to="/withdraw"
              className="w-full px-4 py-2 bg-teal-700 text-white rounded-lg hover:bg-teal-800 transition-colors flex items-center justify-center gap-2 text-[15px]"
            >
              <Wallet className="w-4 h-4" />
              Manage Withdrawals
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}