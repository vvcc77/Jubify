import image_8c8ca35cd09836d3dd58593bbc6624d19ff9bf5b from 'figma:asset/8c8ca35cd09836d3dd58593bbc6624d19ff9bf5b.png'
import image_cc5ec1f0ba36f328f69b36c8446a2702751d9f50 from 'figma:asset/cc5ec1f0ba36f328f69b36c8446a2702751d9f50.png'
import image_09414cd4bc4966c7e94f58168f6465ddea7c9e14 from 'figma:asset/09414cd4bc4966c7e94f58168f6465ddea7c9e14.png'
import { Link } from 'react-router';
import { TrendingUp, Shield, Coins, Brain, Users, ArrowRight, Sparkles, Star } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export default function Home() {
  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-8 py-20 grid md:grid-cols-2 gap-12 items-center">
        <div>
          <div className="inline-block px-4 py-1.5 bg-teal-100 text-teal-800 rounded-full mb-6">Create Your Retirement Fund</div>
          <h1 className="text-5xl text-teal-900 mb-6">Improve Your Future</h1>
          <p className="text-slate-600 mb-8 text-lg">experience a new way to get your pension with more <span className="font-bold">transparency, flexible payouts</span>, insurance and the full <span className="font-bold">control </span>to protect the future of your dear ones or your favorite causes</p>
          <div className="flex gap-4">
            <Link 
              to="/calculator" 
              className="px-8 py-3 bg-teal-700 text-white rounded-full hover:bg-teal-800 transition-colors inline-flex items-center gap-2"
            >
              Let's Build Your Plan
              <ArrowRight className="w-5 h-5" />
            </Link>
            <a href="#stories" className="px-8 py-3 border-2 border-teal-700 text-teal-700 rounded-full hover:bg-teal-50 transition-colors">Read the Stories</a>
          </div>
        </div>
        <div className="relative">
          <div className="rounded-3xl overflow-hidden p-[0px]">
            <ImageWithFallback 
              src={image_cc5ec1f0ba36f328f69b36c8446a2702751d9f50}
              alt="Family planning for future"
              className="w-full h-[500px] object-contain rounded-[0px]"
            />
          </div>
          <div className="absolute bottom-8 right-8 bg-white rounded-2xl shadow-xl p-6 max-w-xs">
            <div className="flex items-start gap-3">
              
              <div>
                
                
                <p className="text-slate-600 mb-3 text-[15px]"><span className="">How to retire at 60 with a significant extra payout a month?</span></p>
                <button className="w-full px-4 py-2 bg-teal-700 text-white rounded-full hover:bg-teal-800 transition-colors flex items-center justify-center gap-2 text-[16px]">
                  <Sparkles className="w-4 h-4" />
                  Ask Your Guide
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-8">
          <h2 className="text-center text-teal-900 text-4xl mb-4">Built for Clarity and Peace</h2>
          <p className="text-center text-slate-600 mb-16 max-w-2xl mx-auto">less complexity, more trust</p>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-8 rounded-2xl hover:bg-slate-50 transition-colors">
              <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center mb-6">
                <TrendingUp className="w-6 h-6 text-teal-700" />
              </div>
              <h3 className="text-teal-900 text-xl mb-3">Automatic Growth</h3>
              <p className="text-slate-600">Smart rebalancing and continous monitoring work silently in the background to maximize your returns without the stress.</p>
            </div>

            <div className="p-8 rounded-2xl hover:bg-slate-50 transition-colors">
              <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center mb-6">
                <Brain className="w-6 h-6 text-teal-700" />
              </div>
              <h3 className="text-teal-900 text-xl mb-3">AI Guidance</h3>
              <p className="text-slate-600">
                The Steward analyzes market trends and your unique family milestones 
                to provide proactive financial advice 24/7.
              </p>
            </div>

            <div className="p-8 rounded-2xl hover:bg-slate-50 transition-colors">
              <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center mb-6">
                <Users className="w-6 h-6 text-teal-700" />
              </div>
              <h3 className="text-teal-900 text-xl mb-3">Simple Inheritance</h3>
              <p className="text-slate-600">Seamlessly designate beneficiaries among your dear ones and no profit causes to help you make a positive impact</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="max-w-7xl mx-auto px-8 py-20" id="stories">
        <div className="text-center mb-16">
          <h2 className="text-teal-900 text-4xl mb-4">See the Stories&nbsp;&nbsp;</h2>
          <p className="text-slate-600 max-w-2xl mx-auto">See how thousands are controlling their financial future with us</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Testimonial 1 */}
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
            <div className="flex items-center gap-4 mb-4">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1765648580575-e1423b361ed5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVlbGFuY2VyJTIwZW50cmVwcmVuZXVyJTIwd29tYW4lMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzc0MTY3MzI3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Sarah Martinez"
                className="w-16 h-16 rounded-full object-cover"
              />
              <div>
                <h4 className="font-semibold text-teal-900">Sarah Martinez</h4>
                <p className="text-sm text-slate-600">Freelance Designer</p>
              </div>
            </div>
            <div className="flex gap-1 mb-4">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
              ))}
            </div>
            <p className="text-slate-600 text-sm leading-relaxed">
              "As a freelancer, I never had access to a proper pension plan. Jubify changed that. 
              The AI guide helped me set up a retirement fund that actually makes sense for my irregular income."
            </p>
          </div>

          {/* Testimonial 2 */}
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
            <div className="flex items-center gap-4 mb-4">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1753164726626-e4c38056a03f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFsbCUyMGJ1c2luZXNzJTIwb3duZXIlMjBtYW4lMjBwb3J0cmFpdHxlbnwxfHx8fDE3NzQxNjczMjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="James Chen"
                className="w-16 h-16 rounded-full object-cover"
              />
              <div>
                <h4 className="font-semibold text-teal-900">James Chen</h4>
                <p className="text-sm text-slate-600">Coffee Shop Owner</p>
              </div>
            </div>
            <div className="flex gap-1 mb-4">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
              ))}
            </div>
            <p className="text-slate-600 text-sm leading-relaxed">
              "Running a small business means every dollar counts. The transparency and low fees of Jubify 
              mean more of my money goes toward my future, not to middlemen. Finally, a pension plan built for people like me."
            </p>
          </div>

          {/* Testimonial 3 */}
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
            <div className="flex items-center gap-4 mb-4">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1753162657060-17c692e18779?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMGVudHJlcHJlbmV1ciUyMGRlc2lnbmVyJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc3NDE2NzMyN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Priya Patel"
                className="w-16 h-16 rounded-full object-cover"
              />
              <div>
                <h4 className="font-semibold text-teal-900">Priya Patel</h4>
                <p className="text-sm text-slate-600">Marketing Consultant</p>
              </div>
            </div>
            <div className="flex gap-1 mb-4">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
              ))}
            </div>
            <p className="text-slate-600 text-sm leading-relaxed">
              "The inheritance features give me peace of mind. I can make sure my family is taken care of, 
              and the blockchain security means everything is transparent and safe. Perfect for self-employed professionals."
            </p>
          </div>
        </div>
      </section>

      {/* Blockchain Features */}
      <section className="max-w-7xl mx-auto px-8 py-20">
        <div className="bg-gradient-to-br from-teal-50 to-blue-50 rounded-3xl p-12">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-teal-900 text-4xl mb-6">Powered by decentralized finance and blockchain technology</h2>
              <p className="text-slate-600 mb-8">
                Your pension fund is secured on the blockchain, ensuring transparency, 
                immutability, and complete ownership of your assets. No middlemen, 
                no hidden fees—just your money, your control.
              </p>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Shield className="w-6 h-6 text-teal-700 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="text-teal-900 font-semibold mb-1">Decentralized Security</h4>
                    <p className="text-slate-600 text-sm">Your funds are protected by cryptographic security, not corporate promises.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Coins className="w-6 h-6 text-teal-700 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="text-teal-900 font-semibold mb-1">Crypto & Traditional Assets</h4>
                    <p className="text-slate-600 text-sm">Diversify across cryptocurrencies and traditional investments in one place.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="rounded-2xl overflow-hidden">
              <ImageWithFallback 
                src={image_8c8ca35cd09836d3dd58593bbc6624d19ff9bf5b}
                alt="Blockchain network"
                className="w-full h-80 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-8 py-20">
        <div className="bg-teal-700 rounded-3xl p-12 text-center text-white">
          <h2 className="text-4xl mb-4">Ready to secure your future?</h2>
          <p className="text-teal-100 mb-8 max-w-2xl mx-auto">
            Join thousands of families who have already taken control of their financial legacy.
          </p>
          <Link 
            to="/calculator" 
            className="px-8 py-3 bg-white text-teal-700 rounded-full hover:bg-slate-100 transition-colors inline-flex items-center gap-2"
          >
            Start Planning Now
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}