import { useState } from 'react';
import { useNavigate, Link } from 'react-router';
import { Plus, Trash2, Users, Wallet, Building2 } from 'lucide-react';
import { AskGuideButton } from '../components/AskGuideButton';

interface Beneficiary {
  id: string;
  type: 'individual' | 'organization';
  name: string;
  relationship: string;
  percentage: number;
  walletAddress?: string;
  iban?: string;
  organizationName?: string;
  paymentMethod?: 'wallet' | 'iban';
}

// Famous non-profits with crypto wallet addresses (powered by Endaoment)
const NON_PROFITS = [
  { name: 'Red Cross', wallet: '0x1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t' },
  { name: 'UNICEF', wallet: '0x2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t1u' },
  { name: 'Doctors Without Borders', wallet: '0x3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t1u2v' },
  { name: 'World Wildlife Fund (WWF)', wallet: '0x4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t1u2v3w' },
  { name: 'Save the Children', wallet: '0x5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t1u2v3w4x' },
  { name: 'The Nature Conservancy', wallet: '0x6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t1u2v3w4x5y' },
  { name: 'Amnesty International', wallet: '0x7g8h9i0j1k2l3m4n5o6p7q8r9s0t1u2v3w4x5y6z' },
  { name: 'Oxfam', wallet: '0x8h9i0j1k2l3m4n5o6p7q8r9s0t1u2v3w4x5y6z7a' },
];

export default function Insurance() {
  const navigate = useNavigate();
  const [beneficiaries, setBeneficiaries] = useState<Beneficiary[]>([
    { id: '1', type: 'individual', name: '', relationship: 'spouse', percentage: 100, paymentMethod: 'iban' }
  ]);
  const [hasChildren, setHasChildren] = useState(false);
  const [numberOfChildren, setNumberOfChildren] = useState(0);

  const addBeneficiary = () => {
    setBeneficiaries([
      ...beneficiaries,
      { id: Date.now().toString(), type: 'individual', name: '', relationship: 'child', percentage: 0, paymentMethod: 'iban' }
    ]);
  };

  const removeBeneficiary = (id: string) => {
    if (beneficiaries.length > 1) {
      setBeneficiaries(beneficiaries.filter(b => b.id !== id));
    }
  };

  const updateBeneficiary = (id: string, field: keyof Beneficiary, value: string | number) => {
    setBeneficiaries(beneficiaries.map(b => {
      if (b.id === id) {
        const updated = { ...b, [field]: value };
        
        // If changing to organization type, prefill with first non-profit
        if (field === 'type' && value === 'organization' && !b.organizationName) {
          updated.organizationName = NON_PROFITS[0].name;
          updated.walletAddress = NON_PROFITS[0].wallet;
          updated.name = NON_PROFITS[0].name;
        }
        
        // If selecting a non-profit, update wallet address
        if (field === 'organizationName') {
          const org = NON_PROFITS.find(np => np.name === value);
          if (org) {
            updated.walletAddress = org.wallet;
            updated.name = org.name;
          }
        }
        
        return updated;
      }
      return b;
    }));
  };

  const totalPercentage = beneficiaries.reduce((sum, b) => sum + b.percentage, 0);

  const handleContinue = () => {
    navigate('/review');
  };

  return (
    <div className="max-w-6xl mx-auto px-8 py-12">
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-4">
          <Link to="/calculator" className="w-8 h-8 bg-teal-700 text-white rounded-full flex items-center justify-center text-sm hover:bg-teal-800 transition-colors cursor-pointer">✓</Link>
          <div className="w-8 h-8 bg-teal-700 text-white rounded-full flex items-center justify-center text-sm">2</div>
          <div className="w-8 h-8 bg-slate-200 text-slate-600 rounded-full flex items-center justify-center text-sm">3</div>
          <div className="w-8 h-8 bg-slate-200 text-slate-600 rounded-full flex items-center justify-center text-sm">4</div>
        </div>
        <h1 className="text-3xl text-teal-900">Inheritance & Beneficiaries</h1>
        <p className="text-slate-600 mt-2">Ensure your legacy passes to the right people</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          {/* Children Information */}
          

          {/* Beneficiaries */}
          <div className="bg-gradient-to-br from-blue-50 to-teal-50 rounded-2xl p-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-teal-900 text-xl">Beneficiaries</h2>
              <button
                onClick={addBeneficiary}
                className="flex items-center gap-2 px-4 py-2 bg-teal-700 text-white rounded-full hover:bg-teal-800 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Beneficiary
              </button>
            </div>

            <div className="space-y-4">
              {beneficiaries.map((beneficiary, index) => (
                <div key={beneficiary.id} className="bg-white rounded-xl p-6">
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-teal-900 font-semibold">Beneficiary {index + 1}</h3>
                    {beneficiaries.length > 1 && (
                      <button
                        onClick={() => removeBeneficiary(beneficiary.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    )}
                  </div>

                  {/* Beneficiary Type */}
                  <div className="mb-4">
                    <label className="block text-slate-700 text-sm mb-2">Beneficiary Type</label>
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        onClick={() => updateBeneficiary(beneficiary.id, 'type', 'individual')}
                        className={`px-4 py-3 rounded-lg border-2 transition-all ${
                          beneficiary.type === 'individual'
                            ? 'border-teal-600 bg-teal-50 text-teal-900'
                            : 'border-slate-200 text-slate-600 hover:border-slate-300'
                        }`}
                      >
                        Individual
                      </button>
                      <button
                        onClick={() => updateBeneficiary(beneficiary.id, 'type', 'organization')}
                        className={`px-4 py-3 rounded-lg border-2 transition-all ${
                          beneficiary.type === 'organization'
                            ? 'border-teal-600 bg-teal-50 text-teal-900'
                            : 'border-slate-200 text-slate-600 hover:border-slate-300'
                        }`}
                      >
                        Organization
                      </button>
                    </div>
                  </div>

                  {beneficiary.type === 'individual' ? (
                    <>
                      {/* Individual Fields */}
                      <div className="grid md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <label className="block text-slate-700 text-sm mb-2">Name</label>
                          <input
                            type="text"
                            value={beneficiary.name}
                            onChange={(e) => updateBeneficiary(beneficiary.id, 'name', e.target.value)}
                            placeholder="Enter name"
                            className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500"
                          />
                        </div>

                        <div>
                          <label className="block text-slate-700 text-sm mb-2">Relationship</label>
                          <select
                            value={beneficiary.relationship}
                            onChange={(e) => updateBeneficiary(beneficiary.id, 'relationship', e.target.value)}
                            className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500"
                          >
                            <option value="spouse">Spouse</option>
                            <option value="child">Child</option>
                            <option value="parent">Parent</option>
                            <option value="sibling">Sibling</option>
                            <option value="friend">Friend</option>
                            <option value="other">Other</option>
                          </select>
                        </div>
                      </div>

                      {/* Payment Method for Individual */}
                      <div className="mb-4">
                        <label className="block text-slate-700 text-sm mb-2">Payment Method</label>
                        
                        {/* Payment Method Selection with Big Icons */}
                        <div className="grid grid-cols-2 gap-3 mb-3">
                          <button
                            onClick={() => updateBeneficiary(beneficiary.id, 'paymentMethod', 'iban')}
                            className={`flex flex-col items-center justify-center gap-2 p-4 rounded-lg border-2 transition-all ${
                              beneficiary.paymentMethod === 'iban'
                                ? 'border-teal-600 bg-teal-50 text-teal-900'
                                : 'border-slate-200 text-slate-600 hover:border-slate-300'
                            }`}
                          >
                            <Building2 className="w-8 h-8" />
                            <span className="text-sm font-medium">IBAN</span>
                          </button>
                          <button
                            onClick={() => updateBeneficiary(beneficiary.id, 'paymentMethod', 'wallet')}
                            className={`flex flex-col items-center justify-center gap-2 p-4 rounded-lg border-2 transition-all ${
                              beneficiary.paymentMethod === 'wallet'
                                ? 'border-teal-600 bg-teal-50 text-teal-900'
                                : 'border-slate-200 text-slate-600 hover:border-slate-300'
                            }`}
                          >
                            <Wallet className="w-8 h-8" />
                            <span className="text-sm font-medium">Crypto Wallet</span>
                          </button>
                        </div>

                        {/* Conditional Input Field */}
                        {beneficiary.paymentMethod === 'wallet' ? (
                          <div>
                            <label className="block text-slate-600 text-xs mb-1">Crypto Wallet Address</label>
                            <input
                              type="text"
                              value={beneficiary.walletAddress || ''}
                              onChange={(e) => updateBeneficiary(beneficiary.id, 'walletAddress', e.target.value)}
                              placeholder="0x..."
                              className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 font-mono text-sm"
                            />
                          </div>
                        ) : (
                          <div>
                            <label className="block text-slate-600 text-xs mb-1">IBAN</label>
                            <input
                              type="text"
                              value={beneficiary.iban || ''}
                              onChange={(e) => updateBeneficiary(beneficiary.id, 'iban', e.target.value)}
                              placeholder="NL00 BANK 0000 0000 00"
                              className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500"
                            />
                          </div>
                        )}
                      </div>
                    </>
                  ) : (
                    <>
                      {/* Organization Fields */}
                      <div className="mb-4">
                        <label className="block text-slate-700 text-sm mb-2">Select Non-Profit</label>
                        <select
                          value={beneficiary.organizationName || ''}
                          onChange={(e) => updateBeneficiary(beneficiary.id, 'organizationName', e.target.value)}
                          className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500"
                        >
                          {NON_PROFITS.map(org => (
                            <option key={org.name} value={org.name}>{org.name}</option>
                          ))}
                        </select>
                      </div>

                      {/* Display Crypto Wallet */}
                      <div className="mb-4">
                        <label className="block text-slate-700 text-sm mb-2">Crypto Wallet Address</label>
                        <div className="px-4 py-3 rounded-lg border border-slate-200 bg-slate-50 font-mono text-sm text-slate-700 break-all">
                          {beneficiary.walletAddress}
                        </div>
                        <p className="text-xs text-slate-500 mt-2 flex items-center gap-1">
                          <span className="inline-block w-2 h-2 bg-teal-600 rounded-full"></span>
                          Powered by Endaoment
                        </p>
                      </div>
                    </>
                  )}

                  {/* Percentage (common for both types) */}
                  <div>
                    <label className="block text-slate-700 text-sm mb-2">Percentage</label>
                    <div className="flex items-center gap-3">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={beneficiary.percentage}
                        onChange={(e) => updateBeneficiary(beneficiary.id, 'percentage', parseInt(e.target.value) || 0)}
                        className="w-24 px-4 py-3 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500"
                      />
                      <span className="text-slate-700">%</span>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={beneficiary.percentage}
                        onChange={(e) => updateBeneficiary(beneficiary.id, 'percentage', parseInt(e.target.value))}
                        className="flex-1 accent-teal-600"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {totalPercentage !== 100 && (
              <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <p className="text-amber-800 text-sm">
                  Total percentage must equal 100%. Currently: {totalPercentage}%
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Summary Panel */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-2xl p-6 shadow-lg sticky top-8">
            <h3 className="text-teal-900 text-lg mb-6">Inheritance Summary</h3>
            
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-4 bg-teal-50 rounded-xl">
                <Users className="w-5 h-5 text-teal-700" />
                <div>
                  <p className="text-sm text-slate-600">Beneficiaries</p>
                  <p className="text-xl text-teal-900">{beneficiaries.length}</p>
                </div>
              </div>

              {hasChildren && (
                <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-xl">
                  <Users className="w-5 h-5 text-blue-700" />
                  <div>
                    <p className="text-sm text-slate-600">Children/Dependents</p>
                    <p className="text-xl text-blue-900">{numberOfChildren}</p>
                  </div>
                </div>
              )}

              <div className={`p-4 rounded-xl ${totalPercentage === 100 ? 'bg-green-50' : 'bg-amber-50'}`}>
                <p className="text-sm text-slate-600 mb-1">Allocation</p>
                <p className={`text-2xl ${totalPercentage === 100 ? 'text-green-900' : 'text-amber-900'}`}>
                  {totalPercentage}%
                </p>
              </div>
            </div>

            <div className="mt-8">
              <button
                onClick={handleContinue}
                disabled={totalPercentage !== 100}
                className="w-full px-6 py-3 bg-teal-700 text-white rounded-full hover:bg-teal-800 transition-colors disabled:bg-slate-300 disabled:cursor-not-allowed"
              >
                Continue to Review
              </button>
            </div>

            <div className="mt-6 p-4 bg-slate-50 rounded-xl">
              <p className="text-xs text-slate-600">
                Your beneficiary information is stored securely on the blockchain and can only be accessed by authorized parties.
              </p>
            </div>

            <div className="mt-4">
              <AskGuideButton />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}