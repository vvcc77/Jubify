import { useState } from 'react';
import { useNavigate, Link } from 'react-router';
import { Bitcoin, CreditCard, Building2, Wallet, CheckCircle2 } from 'lucide-react';
import { AskGuideButton } from '../components/AskGuideButton';

export default function Pay() {
  const navigate = useNavigate();
  const [paymentMethod, setPaymentMethod] = useState<'crypto' | 'card' | null>('card');
  const [selectedCrypto, setSelectedCrypto] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = () => {
    if (paymentMethod === 'crypto' && selectedCrypto && email) {
      navigate('/welcome');
    } else if (paymentMethod === 'card' && cardNumber && cardName && cardExpiry && cardCvv && email) {
      navigate('/welcome');
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-8 py-12">
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-4">
          <Link to="/calculator" className="w-8 h-8 bg-teal-700 text-white rounded-full flex items-center justify-center text-sm hover:bg-teal-800 transition-colors cursor-pointer">✓</Link>
          <Link to="/insurance" className="w-8 h-8 bg-teal-700 text-white rounded-full flex items-center justify-center text-sm hover:bg-teal-800 transition-colors cursor-pointer">✓</Link>
          <Link to="/review" className="w-8 h-8 bg-teal-700 text-white rounded-full flex items-center justify-center text-sm hover:bg-teal-800 transition-colors cursor-pointer">✓</Link>
          <div className="w-8 h-8 bg-teal-700 text-white rounded-full flex items-center justify-center text-sm">4</div>
        </div>
        <h1 className="text-3xl text-teal-900">Activate the Plan</h1>
        <p className="text-slate-600 mt-2">Fund your first contribution to activate yor future fund</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          {/* Payment Method Selection */}
          <div className="bg-gradient-to-br from-blue-50 to-teal-50 rounded-2xl p-8">
            <h2 className="text-teal-900 text-xl mb-6">How do you want to pay?</h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <button
                onClick={() => setPaymentMethod('crypto')}
                className={`p-8 rounded-2xl border-2 transition-all ${
                  paymentMethod === 'crypto'
                    ? 'border-teal-700 bg-teal-50'
                    : 'border-slate-200 bg-white hover:border-teal-300'
                }`}
              >
                <div className="flex flex-col items-center text-center">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-4 ${
                    paymentMethod === 'crypto' ? 'bg-teal-700' : 'bg-slate-100'
                  }`}>
                    <Bitcoin className={`w-8 h-8 ${
                      paymentMethod === 'crypto' ? 'text-white' : 'text-slate-600'
                    }`} />
                  </div>
                  <h3 className="text-teal-900 text-lg font-semibold mb-2">Cryptocurrency</h3>
                  <p className="text-sm text-slate-600">
                    Pay with Bitcoin, Ethereum, or other cryptocurrencies
                  </p>
                  {paymentMethod === 'crypto' && (
                    <CheckCircle2 className="w-6 h-6 text-teal-700 mt-4" />
                  )}
                </div>
              </button>

              <button
                onClick={() => setPaymentMethod('card')}
                className={`p-8 rounded-2xl border-2 transition-all ${
                  paymentMethod === 'card'
                    ? 'border-teal-700 bg-teal-50'
                    : 'border-slate-200 bg-white hover:border-teal-300'
                }`}
              >
                <div className="flex flex-col items-center text-center">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-4 ${
                    paymentMethod === 'card' ? 'bg-teal-700' : 'bg-slate-100'
                  }`}>
                    <CreditCard className={`w-8 h-8 ${
                      paymentMethod === 'card' ? 'text-white' : 'text-slate-600'
                    }`} />
                  </div>
                  <h3 className="text-teal-900 text-lg font-semibold mb-2">Credit Card</h3>
                  <p className="text-sm text-slate-600">
                    Pay with a credit card
                  </p>
                  {paymentMethod === 'card' && (
                    <CheckCircle2 className="w-6 h-6 text-teal-700 mt-4" />
                  )}
                </div>
              </button>
            </div>
          </div>

          {/* Crypto Payment */}
          {paymentMethod === 'crypto' && (
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h2 className="text-teal-900 text-xl mb-6">Connect Crypto Wallet</h2>
              
              <div className="space-y-4">
                <button
                  onClick={() => setSelectedCrypto('metamask')}
                  className={`w-full p-6 rounded-xl border-2 transition-all flex items-center gap-4 ${
                    selectedCrypto === 'metamask'
                      ? 'border-teal-700 bg-teal-50'
                      : 'border-slate-200 hover:border-teal-300'
                  }`}
                >
                  <Wallet className="w-8 h-8 text-orange-600" />
                  <div className="flex-1 text-left">
                    <h3 className="text-teal-900 font-semibold">MetaMask</h3>
                    <p className="text-sm text-slate-600">Connect with MetaMask wallet</p>
                  </div>
                  {selectedCrypto === 'metamask' && (
                    <CheckCircle2 className="w-6 h-6 text-teal-700" />
                  )}
                </button>

                <button
                  onClick={() => setSelectedCrypto('walletconnect')}
                  className={`w-full p-6 rounded-xl border-2 transition-all flex items-center gap-4 ${
                    selectedCrypto === 'walletconnect'
                      ? 'border-teal-700 bg-teal-50'
                      : 'border-slate-200 hover:border-teal-300'
                  }`}
                >
                  <Wallet className="w-8 h-8 text-blue-600" />
                  <div className="flex-1 text-left">
                    <h3 className="text-teal-900 font-semibold">WalletConnect</h3>
                    <p className="text-sm text-slate-600">Connect with any WalletConnect-compatible wallet</p>
                  </div>
                  {selectedCrypto === 'walletconnect' && (
                    <CheckCircle2 className="w-6 h-6 text-teal-700" />
                  )}
                </button>

                <button
                  onClick={() => setSelectedCrypto('coinbase')}
                  className={`w-full p-6 rounded-xl border-2 transition-all flex items-center gap-4 ${
                    selectedCrypto === 'coinbase'
                      ? 'border-teal-700 bg-teal-50'
                      : 'border-slate-200 hover:border-teal-300'
                  }`}
                >
                  <Wallet className="w-8 h-8 text-blue-700" />
                  <div className="flex-1 text-left">
                    <h3 className="text-teal-900 font-semibold">Coinbase Wallet</h3>
                    <p className="text-sm text-slate-600">Connect with Coinbase Wallet</p>
                  </div>
                  {selectedCrypto === 'coinbase' && (
                    <CheckCircle2 className="w-6 h-6 text-teal-700" />
                  )}
                </button>
              </div>

              <div className="mt-6 p-4 bg-blue-50 rounded-xl">
                <p className="text-sm text-blue-900">
                  <strong>Note:</strong> Your first monthly contribution of €500 will be deducted automatically after wallet connection.
                </p>
              </div>
            </div>
          )}

          {/* Credit Card Payment */}
          {paymentMethod === 'card' && (
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h2 className="text-teal-900 text-xl mb-6">Credit Card Details</h2>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-teal-900 mb-2">Card Number</label>
                  <div className="relative">
                    <CreditCard className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      placeholder="1234 5678 9012 3456"
                      className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-teal-900 mb-2">Cardholder Name</label>
                  <input
                    type="text"
                    value={cardName}
                    onChange={(e) => setCardName(e.target.value)}
                    placeholder="John Doe"
                    className="w-full rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 pl-[10px] pr-[16px] py-[12px]"
                  />
                </div>

                <div className="flex gap-4">
                  <div className="w-1/2">
                    <label className="block text-teal-900 mb-2">Expiry Date</label>
                    <input
                      type="text"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      placeholder="MM/YY"
                      className="w-full rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 pl-[10px] pr-[16px] py-[12px]"
                    />
                  </div>

                  <div className="w-1/2">
                    <label className="block text-teal-900 mb-2">CVV</label>
                    <input
                      type="text"
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value)}
                      placeholder="123"
                      className="w-full rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 pl-[10px] pr-[16px] py-[12px]"
                    />
                  </div>
                </div>

                <div className="p-6 bg-slate-50 rounded-xl">
                  <h4 className="text-teal-900 font-semibold mb-3">Automatic Monthly Debit</h4>
                  <div className="space-y-2 text-sm text-slate-600">
                    <p>• Amount: €500 per month</p>
                    <p>• First debit: April 1st, 2026</p>
                    <p>• Description: Jubify Monthly Contribution</p>
                    <p><span className="font-bold">Expected monthly pension: €2,450</span></p>
                    <p><span className="font-bold">Years until retirement: 32</span></p>
                  </div>
                </div>

                <div className="p-4 bg-blue-50 rounded-xl">
                  <p className="text-sm text-blue-900">
                    By providing your credit card details, you authorize Jubify to debit your account monthly for pension contributions.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Summary Panel */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-2xl p-6 shadow-lg sticky top-8">
            <h3 className="text-teal-900 text-lg mb-6">Payment Summary</h3>
            
            <div className="space-y-4 mb-6">
              <div className="pb-4 border-b border-slate-200">
                <p className="text-sm text-slate-600 mb-1">Monthly Contribution</p>
                <p className="text-2xl text-teal-900">€500</p>
              </div>

              <div className="pb-4 border-b border-slate-200">
                <p className="text-sm text-slate-600 mb-1">First Payment</p>
                <p className="text-lg text-teal-900">April 1, 2026</p>
              </div>

              <div className="pb-4 border-b border-slate-200">
                <p className="text-sm text-slate-600 mb-1">Payment Method</p>
                <p className="text-lg text-teal-900">
                  {!paymentMethod && '—'}
                  {paymentMethod === 'crypto' && 'Cryptocurrency'}
                  {paymentMethod === 'card' && 'Credit Card'}
                </p>
              </div>

              {paymentMethod === 'crypto' && selectedCrypto && (
                <div className="pb-4">
                  <p className="text-sm text-slate-600 mb-1">Wallet</p>
                  <p className="text-lg text-teal-900 capitalize">{selectedCrypto}</p>
                </div>
              )}
            </div>

            <div className="mb-6">
              <label className="block text-teal-900 text-sm mb-2">Your Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                autoComplete="email"
                required
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <button
              onClick={handleSubmit}
              disabled={!paymentMethod || (paymentMethod === 'crypto' && !selectedCrypto) || (paymentMethod === 'card' && !cardNumber && !cardName && !cardExpiry && !cardCvv) || !email}
              className="w-full px-6 py-4 bg-teal-700 text-white rounded-full hover:bg-teal-800 transition-colors disabled:bg-slate-300 disabled:cursor-not-allowed mb-4"
            >Activate Your Fund</button>

            <div className="p-4 bg-green-50 rounded-xl">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-green-900">
                  Your payment information is encrypted and secured on the blockchain
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <AskGuideButton />
    </div>
  );
}