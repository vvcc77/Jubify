import { useState } from 'react';
import { useNavigate, Link } from 'react-router';
import { CheckCircle2, Sparkles, AlertCircle, TrendingUp, Users, Calendar } from 'lucide-react';
import { AskGuideButton } from '../components/AskGuideButton';

export default function Review() {
  const navigate = useNavigate();
  const [showAIRecap, setShowAIRecap] = useState(false);

  const handleActivate = () => {
    navigate('/pay');
  };

  const aiRecap = `Based on your information, I've analyzed your retirement plan. Here are my key insights:

• Your retirement age of 67 years and 3 months aligns well with current life expectancy trends.
• Your monthly contribution of €500 is on track to provide a comfortable retirement income.
• With an estimated 8.2% annual growth, your portfolio should grow to approximately €385,000 by retirement.
• Your beneficiary allocation is properly structured to protect your loved ones.
• Consider increasing contributions by 5% annually to offset inflation and maximize growth.

Your plan is solid and positions you well for a secure retirement. I'll continue monitoring market conditions and notify you of optimization opportunities.`;

  return (
    <div className="max-w-6xl mx-auto px-8 py-12">
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-4">
          <Link to="/calculator" className="w-8 h-8 bg-teal-700 text-white rounded-full flex items-center justify-center text-sm hover:bg-teal-800 transition-colors cursor-pointer">✓</Link>
          <Link to="/insurance" className="w-8 h-8 bg-teal-700 text-white rounded-full flex items-center justify-center text-sm hover:bg-teal-800 transition-colors cursor-pointer">✓</Link>
          <div className="w-8 h-8 bg-teal-700 text-white rounded-full flex items-center justify-center text-sm">3</div>
          <div className="w-8 h-8 bg-slate-200 text-slate-600 rounded-full flex items-center justify-center text-sm">4</div>
        </div>
        <h1 className="text-3xl text-teal-900">Review Your Plan</h1>
        <p className="text-slate-600 mt-2">Let's make sure everything looks good before activating</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          {/* Plan Summary */}
          <div className="bg-gradient-to-br from-blue-50 to-teal-50 rounded-2xl p-8">
            <h2 className="text-teal-900 text-xl mb-6">Your Retirement Plan Summary</h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl p-6">
                <div className="flex items-start gap-3 mb-3">
                  <Calendar className="w-5 h-5 text-teal-700 mt-1" />
                  <div>
                    <h3 className="text-teal-900 font-semibold mb-1">Retirement Age</h3>
                    <p className="text-2xl text-teal-900">67 years</p>
                    <p className="text-sm text-slate-600">3 months</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6">
                <div className="flex items-start gap-3 mb-3">
                  <TrendingUp className="w-5 h-5 text-teal-700 mt-1" />
                  <div>
                    <h3 className="text-teal-900 font-semibold mb-1">Monthly Contribution</h3>
                    <p className="text-2xl text-teal-900">€500</p>
                    <p className="text-sm text-slate-600">Automatic monthly deposit</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6">
                <div className="flex items-start gap-3 mb-3">
                  <CheckCircle2 className="w-5 h-5 text-teal-700 mt-1" />
                  <div>
                    <h3 className="text-teal-900 font-semibold mb-1">Expected Monthly Pension</h3>
                    <p className="text-2xl text-teal-900">€2,237</p>
                    <p className="text-sm text-slate-600">Net per month (incl. AOW)</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6">
                <div className="flex items-start gap-3 mb-3">
                  <Users className="w-5 h-5 text-teal-700 mt-1" />
                  <div>
                    <h3 className="text-teal-900 font-semibold mb-1">Beneficiaries</h3>
                    <p className="text-2xl text-teal-900">2</p>
                    <p className="text-sm text-slate-600">100% allocated</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* AI Recap */}
          <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-2xl p-8">
            <div className="flex items-start gap-4 mb-6">
              
              <div>
                <h2 className="text-purple-900 text-xl mb-2">Help me evaluate this plan</h2>
                <p className="text-slate-600">Our AI has reviewed your plan and prepared personalized insights</p>
              </div>
            </div>

            {!showAIRecap ? (
              <button
                onClick={() => setShowAIRecap(true)}
                className="w-full px-6 py-4 bg-purple-600 text-white rounded-xl hover:bg-purple-700 transition-colors flex items-center justify-center gap-2"
              >
                <Sparkles className="w-5 h-5" />
                View AI Recap
              </button>
            ) : (
              <div className="bg-white rounded-xl p-6">
                <div className="prose prose-sm max-w-none">
                  <pre className="whitespace-pre-wrap font-sans text-slate-700 text-sm leading-relaxed">
                    {aiRecap}
                  </pre>
                </div>
                
                <div className="mt-6 flex gap-3">
                  <AskGuideButton />
                  <button 
                    onClick={() => setShowAIRecap(false)}
                    className="px-4 py-3 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    Close
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Important Information */}
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-8">
            <div className="flex items-start gap-4">
              <AlertCircle className="w-6 h-6 text-amber-700 flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-amber-900 font-semibold mb-2">Important Information</h3>
                <ul className="space-y-2 text-sm text-amber-800">
                  <li>• Your funds will be secured on the blockchain using smart contracts</li>
                  <li>- Monthly contributions will be automatically deducted from your connected wallet</li>
                  <li>• You can pause, edit, or adjust your plan at any time from your dashboard</li>
                  <li>• Your beneficiary information is encrypted and stored on-chain</li>
                  <li>• The AI Steward will monitor your portfolio and provide regular insights</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Action Panel */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-2xl p-6 shadow-lg sticky top-8">
            <h3 className="text-teal-900 text-lg mb-6">Ready to Activate?</h3>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <span className="text-sm text-slate-700">Plan configured</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <span className="text-sm text-slate-700">Beneficiaries set</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <span className="text-sm text-slate-700">AI analysis complete</span>
              </div>
            </div>

            <button
              onClick={handleActivate}
              className="w-full px-6 py-4 bg-teal-700 text-white rounded-full hover:bg-teal-800 transition-colors mb-4"
            >
              Activate Plan
            </button>

            <button
              onClick={() => navigate('/calculator')}
              className="w-full px-6 py-3 border-2 border-slate-300 text-slate-700 rounded-full hover:bg-slate-50 transition-colors"
            >
              Edit Plan
            </button>

            <div className="mt-6 p-4 bg-teal-50 rounded-xl">
              <p className="text-xs text-teal-900 mb-2 font-semibold">Next Step</p>
              <p className="text-xs text-slate-600">After activation, you'll connect your wallet or bank account to begin your contributions.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}