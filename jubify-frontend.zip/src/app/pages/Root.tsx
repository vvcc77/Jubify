import { Outlet, Link, useLocation, useNavigate } from 'react-router';
import { Bell, User, LogOut } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';

export default function Root() {
  const location = useLocation();
  const navigate = useNavigate();
  const isHome = location.pathname === '/';
  const isWelcome = location.pathname === '/welcome';
  const isDashboard = location.pathname === '/dashboard';
  const isWithdraw = location.pathname === '/withdraw';
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = () => {
    setIsDropdownOpen(false);
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-teal-50">
      {!isWelcome && (
        <nav className="bg-white border-b border-slate-200 px-8 py-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-12">
              <Link to="/" className="text-2xl font-bold text-teal-700">Jubify</Link>
              <div className="flex gap-8">
                {isHome ? (
                  <>
                    <a href="#how-it-works" className="text-sm text-slate-600 hover:text-teal-700">How it Works</a>
                    <a href="#faq" className="text-sm text-slate-600 hover:text-teal-700">FAQ</a>
                  </>
                ) : (
                  <>
                    <a href="#overview" className={`text-sm hover:text-teal-700 ${isDashboard ? 'text-teal-600' : 'text-slate-600'}`}>
                      {isDashboard && <span className="font-bold">Overview</span>}
                      {!isDashboard && 'Overview'}
                    </a>
                    <a href="#contributions" className="text-sm text-slate-600 hover:text-teal-700">Contributions</a>
                    <a href="#investments" className="text-sm text-slate-600 hover:text-teal-700">Investments</a>
                    <a href="#beneficiaries" className="text-sm text-slate-600 hover:text-teal-700">Beneficiaries</a>
                    <a href="#stats" className="text-sm text-slate-600 hover:text-teal-700">Stats</a>
                    <a href="#payouts" className={`text-sm hover:text-teal-700 ${isWithdraw ? 'text-teal-600' : 'text-slate-600'}`}>
                      {isWithdraw && <span className="font-bold">Payouts</span>}
                      {!isWithdraw && 'Payouts'}
                    </a>
                  </>
                )}
              </div>
            </div>
            <div className="flex items-center gap-4">
              <button className="p-2 hover:bg-slate-100 rounded-full">
                <Bell className="w-5 h-5 text-slate-600" />
              </button>
              <div className="relative" ref={dropdownRef}>
                <button 
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  className="p-2 hover:bg-slate-100 rounded-full"
                >
                  <User className="w-5 h-5 text-slate-600" />
                </button>
                
                {isDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-lg border border-slate-200 py-2 z-50">
                    <button
                      onClick={handleLogout}
                      className="w-full px-4 py-2 text-left text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <LogOut className="w-4 h-4" />
                      Logout
                    </button>
                  </div>
                )}
              </div>
              {isHome && (
                <Link 
                  to="/calculator" 
                  className="px-6 py-2 bg-teal-700 text-white rounded-full hover:bg-teal-800 transition-colors"
                >
                  Get Started
                </Link>
              )}
            </div>
          </div>
        </nav>
      )}
      <main>
        <Outlet />
      </main>
    </div>
  );
}