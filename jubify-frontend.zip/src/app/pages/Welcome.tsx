import { Link } from 'react-router';
import { CheckCircle2, ArrowRight } from 'lucide-react';

export default function Welcome() {
  return (
    <div className="max-w-4xl mx-auto px-8 py-20 text-center">
      <div className="mb-8">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="w-10 h-10 text-green-600" />
        </div>
        <h1 className="text-4xl text-teal-900 mb-4">Welcome to Jubify!</h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Your decentralized pension plan has been successfully activated. 
          You're now on the path to a secure financial future.
        </p>
      </div>

      {/* Success Checklist */}
      <div className="bg-gradient-to-br from-blue-50 to-teal-50 rounded-2xl p-8 mb-12">
        <h2 className="text-teal-900 text-xl mb-6">What's Ready</h2>
        <div className="grid md:grid-cols-2 gap-4 text-left">
          <div className="flex items-start gap-3 bg-white rounded-xl p-4">
            <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-teal-900 font-semibold">Retirement Plan Configured</p>
              <p className="text-sm text-slate-600">Age 67, €500/month contribution</p>
            </div>
          </div>
          <div className="flex items-start gap-3 bg-white rounded-xl p-4">
            <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-teal-900 font-semibold">Payment Method Connected</p>
              <p className="text-sm text-slate-600">First payment: April 1, 2026</p>
            </div>
          </div>
          <div className="flex items-start gap-3 bg-white rounded-xl p-4">
            <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-teal-900 font-semibold">Beneficiaries Designated</p>
              <p className="text-sm text-slate-600">100% allocation complete</p>
            </div>
          </div>
          <div className="flex items-start gap-3 bg-white rounded-xl p-4">
            <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-teal-900 font-semibold">AI Steward Activated</p>
              <p className="text-sm text-slate-600">Portfolio monitoring enabled</p>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-center items-center">
        <Link 
          to="/dashboard"
          className="px-8 py-4 bg-teal-700 text-white rounded-full hover:bg-teal-800 transition-colors flex items-center gap-2"
        >
          Check Your Plan
          <ArrowRight className="w-5 h-5" />
        </Link>
      </div>

      {/* Information Box */}
      <div className="mt-12 p-6 bg-purple-50 rounded-2xl border border-purple-200">
        <p className="text-sm text-purple-900">
          <strong>Important:</strong> You'll receive a confirmation email shortly with all your plan details. 
          The AI Steward will send you monthly updates on your portfolio performance.
        </p>
      </div>
    </div>
  );
}