import { useState } from 'react';
import { Link } from 'react-router';
import { 
  TrendingDown, 
  Wallet,
  Calendar,
  DollarSign,
  Brain,
  AlertCircle,
  CheckCircle2,
  Bitcoin,
  Building2
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

export default function Withdraw() {
  const [withdrawalType, setWithdrawalType] = useState<'monthly' | 'lump' | null>(null);
  const [monthlyAmount, setMonthlyAmount] = useState(2237);
  const [lumpSumAmount, setLumpSumAmount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState<'crypto' | 'bank' | null>(null);
  const [isAlive, setIsAlive] = useState(true);

  const totalPortfolio = 385000;
  const maxMonthlyWithdrawal = 3500;

  const allocationData = [
    { name: 'Crypto Assets', value: 35, color: '#0d9488' },
    { name: 'Stocks', value: 40, color: '#14b8a6' },
    { name: 'Bonds', value: 20, color: '#5eead4' },
    { name: 'Stable Coins', value: 5, color: '#99f6e4' },
  ];

  const handleWithdraw = () => {
    // Mock withdrawal logic
    alert('Withdrawal request submitted successfully!');
  };

  return (
    <div className="max-w-6xl mx-auto px-8 py-12">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl text-teal-900">Withdraw your Payouts</h1>
          <p className="text-slate-600 mt-2">Manage your retirement income</p>
        </div>
        
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          {/* Proof of Life */}
          <div className="bg-gradient-to-br from-green-50 to-teal-50 rounded-2xl p-8 border border-green-200">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h2 className="text-teal-900 text-xl mb-2">Proof of Life Verification</h2>
                <p className="text-slate-600 text-sm">
                  Confirm you're alive to continue receiving pension payments
                </p>
              </div>
              <div className={`px-4 py-2 rounded-full ${isAlive ? 'bg-green-600' : 'bg-red-600'} text-white`}>
                {isAlive ? 'Verified' : 'Pending'}
              </div>
            </div>
            
            {isAlive ? (
              <div className="flex items-center gap-3 p-4 bg-white rounded-xl">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
                <div>
                  <p className="text-teal-900 font-semibold">Verification Active</p>
                  <p className="text-sm text-slate-600">Last verified: March 22, 2026</p>
                  <p className="text-sm text-slate-600">Next verification due: April 22, 2026</p>
                </div>
              </div>
            ) : (
              <button className="w-full px-6 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors">
                Verify Now
              </button>
            )}
          </div>

          {/* Withdrawal Type */}
          <div className="bg-gradient-to-br from-blue-50 to-teal-50 rounded-2xl p-8">
            <h2 className="text-teal-900 text-xl mb-6">Withdrawal Type</h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <button
                onClick={() => setWithdrawalType('monthly')}
                className={`p-6 rounded-2xl border-2 transition-all text-center ${
                  withdrawalType === 'monthly'
                    ? 'border-teal-700 bg-teal-50'
                    : 'border-slate-200 bg-white hover:border-teal-300'
                }`}
              >
                <div className="flex justify-center">
                  <Calendar className={`w-10 h-10 mb-4 ${
                    withdrawalType === 'monthly' ? 'text-teal-700' : 'text-slate-600'
                  }`} />
                </div>
                <h3 className="text-teal-900 font-semibold mb-2">Monthly Pension</h3>
                <p className="text-sm text-slate-600">
                  Receive regular monthly payments for steady income
                </p>
                {withdrawalType === 'monthly' && (
                  <div className="flex justify-center mt-4">
                    <CheckCircle2 className="w-6 h-6 text-teal-700" />
                  </div>
                )}
              </button>

              <button
                onClick={() => setWithdrawalType('lump')}
                className={`p-6 rounded-2xl border-2 transition-all text-center ${
                  withdrawalType === 'lump'
                    ? 'border-teal-700 bg-teal-50'
                    : 'border-slate-200 bg-white hover:border-teal-300'
                }`}
              >
                <div className="flex justify-center">
                  <DollarSign className={`w-10 h-10 mb-4 ${
                    withdrawalType === 'lump' ? 'text-teal-700' : 'text-slate-600'
                  }`} />
                </div>
                <h3 className="text-teal-900 font-semibold mb-2">Lump Sum</h3>
                <p className="text-sm text-slate-600">Withdraw your one-time amount for larger expenses</p>
                {withdrawalType === 'lump' && (
                  <div className="flex justify-center mt-4">
                    <CheckCircle2 className="w-6 h-6 text-teal-700" />
                  </div>
                )}
              </button>
            </div>
          </div>

          {/* Monthly Withdrawal */}
          {withdrawalType === 'monthly' && (
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h2 className="text-teal-900 text-xl mb-6">Set Monthly Withdrawal Amount</h2>
              
              <div className="mb-6">
                <label className="block text-teal-900 mb-2">Monthly Amount</label>
                <div className="flex items-center gap-4 mb-4">
                  <input
                    type="number"
                    min="0"
                    max={maxMonthlyWithdrawal}
                    value={monthlyAmount}
                    onChange={(e) => setMonthlyAmount(parseInt(e.target.value) || 0)}
                    className="w-32 px-4 py-3 rounded-xl border border-teal-200 focus:outline-none focus:ring-2 focus:ring-teal-500 text-xl font-semibold"
                  />
                  <span className="text-teal-900 text-xl">$</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max={maxMonthlyWithdrawal}
                  value={monthlyAmount}
                  onChange={(e) => setMonthlyAmount(parseInt(e.target.value))}
                  className="w-full accent-teal-600"
                />
                <div className="flex justify-between mt-2 text-sm text-slate-600">
                  <span>$0</span>
                  <span>Max: ${maxMonthlyWithdrawal}</span>
                </div>
              </div>

              <div className="p-4 bg-blue-50 rounded-xl mb-6">
                <p className="text-sm text-blue-900">
                  <strong>Estimated duration:</strong> With ${monthlyAmount} monthly withdrawals, 
                  your pension will last approximately {Math.floor(totalPortfolio / monthlyAmount / 12)} years.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-slate-50 rounded-xl">
                  <p className="text-sm text-slate-600 mb-1">First Payment</p>
                  <p className="text-lg text-teal-900 font-semibold">April 1, 2026</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-xl">
                  <p className="text-sm text-slate-600 mb-1">Frequency</p>
                  <p className="text-lg text-teal-900 font-semibold">Monthly</p>
                </div>
              </div>
            </div>
          )}

          {/* Lump Sum Withdrawal */}
          {withdrawalType === 'lump' && (
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h2 className="text-teal-900 text-xl mb-6">One-time Lump Sum Withdrawal</h2>
              
              <div className="mb-6">
                <label className="block text-teal-900 mb-2">Amount to Withdraw</label>
                <div className="flex items-center gap-4">
                  <span className="text-2xl text-teal-900">$</span>
                  <input
                    type="number"
                    min="0"
                    max={totalPortfolio}
                    value={lumpSumAmount}
                    onChange={(e) => setLumpSumAmount(Number(e.target.value))}
                    className="flex-1 px-4 py-3 rounded-xl border border-teal-200 focus:outline-none focus:ring-2 focus:ring-teal-500 text-xl font-semibold"
                  />
                </div>
                <p className="text-sm text-slate-600 mt-2">Maximum: $25,000</p>
              </div>

              {/* Payment Method */}
              <div className="mb-6">
                <h3 className="text-teal-900 mb-4">Payment Method</h3>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <button
                    onClick={() => setPaymentMethod('crypto')}
                    className={`p-6 rounded-2xl border-2 transition-all text-center ${
                      paymentMethod === 'crypto'
                        ? 'border-teal-700 bg-teal-50'
                        : 'border-slate-200 bg-white hover:border-teal-300'
                    }`}
                  >
                    <div className="flex justify-center mb-4">
                      <Bitcoin className={`w-8 h-8 ${
                        paymentMethod === 'crypto' ? 'text-teal-700' : 'text-slate-600'
                      }`} />
                    </div>
                    <h3 className="text-teal-900 font-semibold mb-1">Crypto Wallet</h3>
                    <p className="text-sm text-slate-600">
                      Receive payments in cryptocurrency
                    </p>
                    {paymentMethod === 'crypto' && (
                      <div className="flex justify-center mt-4">
                        <CheckCircle2 className="w-6 h-6 text-teal-700" />
                      </div>
                    )}
                  </button>

                  <button
                    onClick={() => setPaymentMethod('bank')}
                    className={`p-6 rounded-2xl border-2 transition-all text-center ${
                      paymentMethod === 'bank'
                        ? 'border-teal-700 bg-teal-50'
                        : 'border-slate-200 bg-white hover:border-teal-300'
                    }`}
                  >
                    <div className="flex justify-center mb-4">
                      <Building2 className={`w-8 h-8 ${
                        paymentMethod === 'bank' ? 'text-teal-700' : 'text-slate-600'
                      }`} />
                    </div>
                    <h3 className="text-teal-900 font-semibold mb-1">Bank Account</h3>
                    <p className="text-sm text-slate-600">
                      Direct deposit to your bank
                    </p>
                    {paymentMethod === 'bank' && (
                      <div className="flex justify-center mt-4">
                        <CheckCircle2 className="w-6 h-6 text-teal-700" />
                      </div>
                    )}
                  </button>
                </div>
              </div>

              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl mb-6">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-amber-700 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm text-amber-900">
                      <strong>Warning:</strong> Withdrawing a large lump sum may have tax implications 
                      and will reduce your remaining pension balance.
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl">
                <p className="text-2xl text-teal-900 font-semibold">
                  ${(totalPortfolio - lumpSumAmount).toLocaleString()}
                </p>
                <p className="text-xs text-slate-600 mt-1">Remaining Balance After Withdrawal</p>
              </div>
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Portfolio Summary */}
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <h3 className="text-teal-900 text-lg mb-6">Portfolio Summary</h3>
            
            <div className="mb-6">
              <p className="text-sm text-slate-600 mb-1">Total Value</p>
              <p className="text-3xl text-teal-900 font-semibold">${totalPortfolio.toLocaleString()}</p>
            </div>

            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={allocationData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {allocationData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>

            <div className="space-y-2 mt-4">
              {allocationData.map((item) => (
                <div key={item.name} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-slate-700">{item.name}</span>
                  </div>
                  <span className="text-teal-900 font-semibold">{item.value}%</span>
                </div>
              ))}
            </div>
          </div>

          {/* AI Recommendation */}
          <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-2xl p-6 border border-purple-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-purple-900 font-semibold">AI Recommendation</h3>
            </div>
            <p className="text-sm text-slate-700 mb-4">
              Based on your portfolio and life expectancy, I recommend a monthly withdrawal 
              of $2,237 to ensure your pension lasts for 25+ years.
            </p>
          </div>

          {/* Submit Button */}
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <button
              onClick={handleWithdraw}
              disabled={!withdrawalType || !paymentMethod || !isAlive}
              className="w-full px-6 py-4 bg-teal-700 text-white rounded-full hover:bg-teal-800 transition-colors disabled:bg-slate-300 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              <Wallet className="w-5 h-5" />
              {withdrawalType === 'monthly' ? 'Activate Monthly Payments' : 'Request Withdrawal'}
            </button>

            {(!withdrawalType || !paymentMethod) && (
              <p className="text-sm text-slate-600 text-center mt-4">
                Please select withdrawal type and payment method
              </p>
            )}
          </div>

          {/* Information */}
          <div className="bg-teal-50 rounded-2xl p-6 border border-teal-200">
            <p className="text-xs text-teal-900">
              <strong>Note:</strong> All withdrawals are processed through smart contracts 
              on the blockchain. Crypto payments are instant, while bank transfers may take 1-3 business days.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}