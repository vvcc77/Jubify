import { createBrowserRouter } from "react-router";
import Root from "./pages/Root";
import Home from "./pages/Home";
import Calculator from "./pages/Calculator";
import Insurance from "./pages/Insurance";
import Review from "./pages/Review";
import Pay from "./pages/Pay";
import Welcome from "./pages/Welcome";
import Dashboard from "./pages/Dashboard";
import Withdraw from "./pages/Withdraw";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "calculator", Component: Calculator },
      { path: "insurance", Component: Insurance },
      { path: "review", Component: Review },
      { path: "pay", Component: Pay },
      { path: "welcome", Component: Welcome },
      { path: "dashboard", Component: Dashboard },
      { path: "withdraw", Component: Withdraw },
    ],
  },
]);
