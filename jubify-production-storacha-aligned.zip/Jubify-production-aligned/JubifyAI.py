# { "Depends": "py-genlayer:1jb45aa8ynh2a9c9xn3b7qqh8sm5q93hwfp7jqmwsfhh8jpz09h6" }
from genlayer import *
import json


class JubifyAI(gl.Contract):
    """
    Intelligent Contract aligned with the Storacha flow.

    Design rules:
    - Backend remains the canonical source of state.
    - Storacha provides immutable CID-based snapshots.
    - This contract reads stable JSON from a gateway URL and returns compact decisions.
    - The contract stores only compact outputs and source URLs/CIDs for traceability.
    """

    passport_urls: TreeMap[Address, str]
    allocation_decisions: TreeMap[Address, str]
    monitoring_decisions: TreeMap[Address, str]

    def __init__(self):
        pass

    @gl.public.write
    def evaluate_plan_from_passport_url(self, user_address: str, passport_url: str, market_snapshot_json: str) -> None:
        """
        Reads a stable RetirementPassport JSON from a CID-backed gateway URL and
        combines it with a normalized market snapshot provided by the backend.
        """

        def fetch_passport_json() -> str:
            response = gl.nondet.web.get(passport_url)
            return response.body.decode("utf-8")

        passport_json = gl.eq_principle.strict_eq(fetch_passport_json)
        market = json.loads(market_snapshot_json)
        passport = json.loads(passport_json)

        combined = json.dumps(
            {
                "passport": passport,
                "market": market,
            },
            sort_keys=True,
            separators=(",", ":"),
        )

        task = """
You are the allocation policy evaluator for a retirement savings product.
Read the normalized input JSON and return ONLY minified JSON with this exact schema:
{
  "decision":"ALLOW|WATCH|REBALANCE|BLOCK",
  "recommendedStrategy":"CONSERVATIVE|BALANCED|GROWTH",
  "recommendedProtocol":"string",
  "confidence":"low|medium|high",
  "maxAllocationPct":0,
  "reasonShort":"string"
}
"""

        criteria = """
- Output MUST be valid minified JSON and nothing else.
- decision must be one of: ALLOW, WATCH, REBALANCE, BLOCK.
- recommendedStrategy must be one of: CONSERVATIVE, BALANCED, GROWTH.
- recommendedProtocol must name one candidate present in the market snapshot, unless decision is BLOCK.
- maxAllocationPct must be an integer between 0 and 100.
- reasonShort must be short, factual, and must not invent external data.
- Higher APY alone is not enough; also consider TVL and user risk profile.
- If the profile looks conservative, prefer simpler and lower-risk candidates.
- If the data looks weak, contradictory, or incomplete, prefer WATCH or BLOCK.
"""

        result = gl.eq_principle.prompt_non_comparative(
            lambda: combined,
            task=task,
            criteria=criteria,
        )

        addr = Address(user_address)
        self.passport_urls[addr] = passport_url
        self.allocation_decisions[addr] = result

    @gl.public.write
    def monitor_position_from_url(self, user_address: str, position_url: str, market_snapshot_json: str) -> None:
        def fetch_position_json() -> str:
            response = gl.nondet.web.get(position_url)
            return response.body.decode("utf-8")

        position_json = gl.eq_principle.strict_eq(fetch_position_json)
        position = json.loads(position_json)
        market = json.loads(market_snapshot_json)

        combined = json.dumps(
            {
                "position": position,
                "market": market,
            },
            sort_keys=True,
            separators=(",", ":"),
        )

        task = """
You are monitoring an active retirement allocation.
Return ONLY minified JSON with this exact schema:
{
  "status":"HEALTHY|DEGRADED|REBALANCE|PAUSE",
  "nextAction":"KEEP|WATCH|REBALANCE|PAUSE_NEW_CONTRIBUTIONS",
  "targetStrategy":"CONSERVATIVE|BALANCED|GROWTH",
  "targetProtocol":"string",
  "reasonShort":"string"
}
"""

        criteria = """
- Output MUST be valid minified JSON and nothing else.
- status must be one of: HEALTHY, DEGRADED, REBALANCE, PAUSE.
- nextAction must be one of: KEEP, WATCH, REBALANCE, PAUSE_NEW_CONTRIBUTIONS.
- targetStrategy must be one of: CONSERVATIVE, BALANCED, GROWTH.
- targetProtocol must name one candidate from the market snapshot, unless nextAction is PAUSE_NEW_CONTRIBUTIONS.
- reasonShort must be short, factual, and tied to the given JSON.
- Do not invent trade execution details.
- If data quality is weak or contradictory, prefer WATCH or PAUSE_NEW_CONTRIBUTIONS.
"""

        result = gl.eq_principle.prompt_non_comparative(
            lambda: combined,
            task=task,
            criteria=criteria,
        )

        self.monitoring_decisions[Address(user_address)] = result

    @gl.public.view
    def get_passport_url(self, address: str) -> str:
        result = self.passport_urls.get(Address(address), None)
        return "" if result is None else result

    @gl.public.view
    def get_allocation_decision(self, address: str) -> str:
        result = self.allocation_decisions.get(Address(address), None)
        if result is None:
            return '{"error":"NO_ALLOCATION_DECISION"}'
        return result

    @gl.public.view
    def get_monitoring_decision(self, address: str) -> str:
        result = self.monitoring_decisions.get(Address(address), None)
        if result is None:
            return '{"error":"NO_MONITORING_DECISION"}'
        return result
