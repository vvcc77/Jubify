# PRODUCTION HANDOFF

## Objetivo

Subir una versión alineada con el repo público actual de JUBIFY sin romper:
- la tesis del producto,
- el backend demo-first,
- el vault en Avalanche,
- la capa AI/GenLayer,
- ni la UX del frontend existente.

## Archivos que reemplaza este paquete

1. `README.md`
2. `JubifyVault.sol`
3. `JubifyAI.py`
4. `jubify-backend.zip`

## Archivo que se preserva

- `jubify-frontend.zip`

## Orden sugerido de actualización

1. Reemplazar `README.md`
2. Reemplazar `JubifyVault.sol`
3. Reemplazar `JubifyAI.py`
4. Reemplazar `jubify-backend.zip`
5. Verificar que el frontend siga apuntando al backend esperado
6. Probar entorno demo con `INTEGRATION_MODE=mock`
7. Activar Storacha con `STORACHA_ENABLED=true`
8. Probar sync manual de passport y artifacts
9. Recién después probar endpoints reales de Avalanche / GenLayer / Storacha

## Checklist mínimo post-subida

- [ ] El README describe Storacha como capa derivada, no fuente de verdad
- [ ] El vault compila en Solidity 0.8.29
- [ ] El contract AI compila/lintea en entorno GenLayer
- [ ] El backend levanta con `npm install && npm run dev`
- [ ] `/health` responde
- [ ] `/integrations/status` incluye `storacha`
- [ ] `/storacha/:userId/artifacts` responde autenticado
- [ ] `POST /storacha/:userId/passport/sync` produce resultado controlado
- [ ] El dashboard no se rompe si Storacha falla

## Riesgos conocidos

- No se validó upload real contra Storacha desde este entorno aislado
- No se desplegó ni compiló live Avalanche/GenLayer desde este entorno
- `jubify-frontend.zip` queda fuera del scope de este paquete
