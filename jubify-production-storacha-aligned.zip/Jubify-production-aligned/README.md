# Jubify

> La pensión que el sistema no te dio.

Repositorio alineado para producción/handoff del proyecto **JUBIFY**.

## Qué se actualizó

Este paquete está alineado con la estructura actual del repositorio público:

- `JubifyVault.sol`
- `JubifyAI.py`
- `jubify-backend.zip`
- `README.md`

## Cambios principales incluidos

### 1. Storacha integrado sin romper la arquitectura
Storacha entra como capa de almacenamiento derivado por CID para:
- `retirement_passport`
- `market_snapshot`
- `ai_decision`
- `liveness_record`
- `inheritance_instruction`

No reemplaza:
- backend canónico,
- vault on-chain,
- ni lógica de GenLayer.

### 2. Backend alineado
El `jubify-backend.zip` incluye:
- módulo Storacha en TypeScript/Fastify,
- generación de retirement passport,
- persistencia in-memory de artefactos,
- rutas manuales de sync,
- integración en health/dashboard,
- fallback elegante si Storacha falla.

### 3. Smart contract Avalanche alineado
`JubifyVault.sol` ahora soporta referencias CID:
- `profileCID`
- `decisionCID`
- `inheritanceCID`
- `livenessCID`

### 4. Intelligent Contract GenLayer alineado
`JubifyAI.py` ahora puede:
- leer un passport por URL/CID,
- combinarlo con snapshot de mercado,
- emitir decisiones compactas,
- y dejar trazabilidad reproducible.

## Cómo subir esto al repo actual

### Reemplazar en la raíz del repo:
- `README.md`
- `JubifyVault.sol`
- `JubifyAI.py`
- `jubify-backend.zip`

### Mantener sin cambios
- `jubify-frontend.zip` (este paquete no lo toca)

## Qué carpeta mirar si querés auditar el backend antes de comprimir
- `jubify-backend-source/`

## Punto clave
Este paquete está **alineado a la estructura real publicada** del repo y sirve como handoff técnico.
Aun así, las integraciones live con Storacha / GenLayer / Avalanche deben validarse en el entorno del equipo antes de deploy final.
