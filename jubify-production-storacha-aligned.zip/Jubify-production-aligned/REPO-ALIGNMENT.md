# REPO ALIGNMENT

## Estructura de referencia del repo público

La estructura pública observada en el repositorio de GitHub contiene en raíz:
- `JubifyAI.py`
- `JubifyVault.sol`
- `README.md`
- `jubify-backend.zip`
- `jubify-frontend.zip`

Este paquete respeta esa forma de publicación.

## Decisión de empaquetado

Para minimizar fricción:
- se entrega el nuevo `jubify-backend.zip` listo para reemplazo,
- se mantiene el nombre de `JubifyAI.py`,
- se mantiene el nombre de `JubifyVault.sol`,
- no se toca `jubify-frontend.zip`.
