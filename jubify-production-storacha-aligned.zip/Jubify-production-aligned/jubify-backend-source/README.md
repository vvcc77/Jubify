# JUBIFY Backend

Backend modular, tipado y demo-first para JUBIFY.

## Qué trae

- Fastify + TypeScript
- Validación estricta con Zod
- Arquitectura modular simple
- Repositorios in-memory listos para demo
- Session auth simple para prototipo
- Event log / audit trail
- Dashboard consolidado
- Adapters mock y reales para Avalanche y GenLayer
- Integración Storacha/IPFS best-effort para snapshots derivados
- Modo degradado elegante si las integraciones fallan

## Filosofía

Esto levanta **sin base externa**.
La persistencia por defecto es en memoria para no matar la demo.
La siguiente capa natural es agregar PostgreSQL/Prisma sin romper contratos ni servicios.

Storacha entra como **capa derivada**:
- no es fuente de verdad,
- no bloquea onboarding,
- no reemplaza backend ni vault,
- y solo guarda artefactos minimizados por CID.

## Requisitos

- Node.js 22+
- npm 10+

## Instalación

```bash
npm install
cp .env.example .env
npm run dev
```

Servidor por defecto en:

```txt
http://localhost:3001
```

## Scripts

```bash
npm run dev
npm run build
npm run start
npm run check
```

## Modos de integración

- `mock`: usa siempre providers mock.
- `hybrid`: intenta provider real y si falla, cae a mock.
- `real`: intenta provider real; si falla, responde con degradación y último fallback disponible.

## Storacha

### Variables

- `STORACHA_ENABLED`
- `STORACHA_UPLOAD_URL`
- `STORACHA_GATEWAY_BASE`
- `STORACHA_AUTH_TOKEN`
- `STORACHA_TIMEOUT_MS`
- `STORACHA_WRITE_CIDS_ONCHAIN`

### Qué archiva

- `retirement_passport`
- `market_snapshot`
- `ai_decision`
- `liveness_record`
- `inheritance_instruction`

### Qué NO archivar en claro

- email
- nombre real
- datos bancarios
- notas internas
- beneficiarios con PII innecesaria

## Flujo mínimo de prueba

### 1) Login demo

```bash
curl -X POST http://localhost:3001/auth/demo-login   -H "content-type: application/json"   -d '{"demoUser":"default"}'
```

Guarda `accessToken`.

### 2) Consultar onboarding

```bash
curl http://localhost:3001/onboarding/state   -H "authorization: Bearer TU_TOKEN"
```

### 3) Ver dashboard

```bash
curl http://localhost:3001/dashboard/usr_demo_001   -H "authorization: Bearer TU_TOKEN"
```

### 4) Forzar sync manual del passport

```bash
curl -X POST http://localhost:3001/storacha/usr_demo_001/passport/sync   -H "authorization: Bearer TU_TOKEN"
```

### 5) Ver artefactos Storacha

```bash
curl http://localhost:3001/storacha/usr_demo_001/artifacts   -H "authorization: Bearer TU_TOKEN"
```

## Endpoints

### Auth
- `POST /auth/demo-login`
- `POST /auth/email-login`
- `POST /auth/wallet-connect`

### Onboarding / Profile
- `GET /onboarding/state`
- `POST /onboarding/profile`
- `POST /onboarding/preferences`

### Plan
- `POST /plan`
- `GET /plan/:userId`
- `PATCH /plan/:userId/contribution`

### Retirement
- `POST /plan/:userId/retirement`
- `GET /plan/:userId/retirement`

### Protection / Inheritance
- `POST /plan/:userId/protection`
- `POST /plan/:userId/inheritance`
- `GET /plan/:userId/inheritance`

### Events
- `GET /plan/:userId/events`

### Dashboard
- `GET /dashboard/:userId`

### Health / Integrations
- `GET /health`
- `GET /integrations/status`

### Storacha
- `GET /storacha/:userId/artifacts`
- `POST /storacha/:userId/passport/sync`
- `POST /storacha/:userId/inheritance/sync`
- `POST /storacha/:userId/market-snapshot`
- `POST /storacha/:userId/ai-decision`
- `POST /storacha/:userId/liveness`
