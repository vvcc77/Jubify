import dotenv from 'dotenv';
import { z } from 'zod';

dotenv.config();

const booleanish = z.preprocess((value) => {
  if (typeof value === 'string') {
    return ['1', 'true', 'yes', 'on'].includes(value.toLowerCase());
  }
  return value;
}, z.boolean());

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().positive().default(3001),
  APP_MODE: z.enum(['demo', 'standard']).default('demo'),
  SESSION_TTL_HOURS: z.coerce.number().int().positive().default(12),

  INTEGRATION_MODE: z.enum(['mock', 'hybrid', 'real']).default('hybrid'),

  RATE_LIMIT_WINDOW_MS: z.coerce.number().int().positive().default(60_000),
  RATE_LIMIT_AUTH_MAX: z.coerce.number().int().positive().default(20),
  RATE_LIMIT_PUBLIC_MAX: z.coerce.number().int().positive().default(60),

  AVALANCHE_RPC_URL: z.string().url().optional().or(z.literal('')),
  AVALANCHE_CHAIN_ID: z.string().default('43114'),
  AVALANCHE_VAULT_ADDRESS: z.string().optional().or(z.literal('')),
  AVALANCHE_TIMEOUT_MS: z.coerce.number().int().positive().default(3500),

  GENLAYER_API_URL: z.string().url().optional().or(z.literal('')),
  GENLAYER_TIMEOUT_MS: z.coerce.number().int().positive().default(3500),
  GENLAYER_FROM_ADDRESS: z.string().optional().or(z.literal('')),
  GENLAYER_CONTRACT_ADDRESS: z.string().optional().or(z.literal('')),
  GENLAYER_PROTECTION_CALL_DATA: z.string().optional().or(z.literal('')),
  GENLAYER_RETIREMENT_CALL_DATA: z.string().optional().or(z.literal('')),
  GENLAYER_PROOF_OF_LIFE_CALL_DATA: z.string().optional().or(z.literal('')),

  STORACHA_ENABLED: booleanish.default(false),
  STORACHA_UPLOAD_URL: z.string().url().default('https://up.storacha.network/upload'),
  STORACHA_GATEWAY_BASE: z.string().url().default('https://storacha.link/ipfs'),
  STORACHA_AUTH_TOKEN: z.string().optional().or(z.literal('')),
  STORACHA_TIMEOUT_MS: z.coerce.number().int().positive().default(8000),
  STORACHA_WRITE_CIDS_ONCHAIN: booleanish.default(false)
});

export const env = envSchema.parse(process.env);
