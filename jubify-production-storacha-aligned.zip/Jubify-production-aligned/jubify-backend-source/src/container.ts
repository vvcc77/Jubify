import { env } from './config/env';
import { MemoryStore } from './infra/memory/store';
import {
  ArtifactRepository,
  BeneficiaryRepository,
  EventLogRepository,
  IntegrationStateRepository,
  PlanRepository,
  ProfileRepository,
  ProtectionRepository,
  RetirementRepository,
  SessionRepository,
  UserRepository
} from './infra/memory/repositories';
import { EventsService } from './modules/events/events.service';
import { AuthService } from './modules/auth/auth.service';
import { ProfileService } from './modules/profile/profile.service';
import { OnboardingService } from './modules/onboarding/onboarding.service';
import { PlanService } from './modules/plan/plan.service';
import { RetirementService } from './modules/retirement/retirement.service';
import { ProtectionService } from './modules/protection/protection.service';
import { MockAvalancheAdapter } from './modules/integrations/mocks/mock-avalanche.adapter';
import { MockGenLayerAdapter } from './modules/integrations/mocks/mock-genlayer.adapter';
import { AvalancheAdapter } from './modules/integrations/avalanche/avalanche.adapter';
import { GenLayerAdapter } from './modules/integrations/genlayer/genlayer.adapter';
import { IntegrationsService } from './modules/integrations/integrations.service';
import { DashboardService } from './modules/dashboard/dashboard.service';
import { seedDemo } from './seed';
import { getStorachaConfig } from './modules/integrations/storacha/storacha.config';
import { StorachaAdapter } from './modules/integrations/storacha/storacha.adapter';
import { StorachaService } from './modules/integrations/storacha/storacha.service';
import { RetirementPassportService } from './modules/passport/retirement-passport.service';
import { StorachaArtifactsService } from './modules/integrations/storacha/storacha-artifacts.service';

export type AppContainer = ReturnType<typeof buildContainer>;

export function buildContainer() {
  const store = new MemoryStore();

  const userRepo = new UserRepository(store);
  const sessionRepo = new SessionRepository(store);
  const profileRepo = new ProfileRepository(store);
  const planRepo = new PlanRepository(store);
  const retirementRepo = new RetirementRepository(store);
  const protectionRepo = new ProtectionRepository(store);
  const beneficiaryRepo = new BeneficiaryRepository(store);
  const eventRepo = new EventLogRepository(store);
  const integrationStateRepo = new IntegrationStateRepository(store);
  const artifactRepo = new ArtifactRepository(store);

  const eventsService = new EventsService(eventRepo);
  const authService = new AuthService(userRepo, sessionRepo, env.SESSION_TTL_HOURS);
  const profileService = new ProfileService(profileRepo, eventsService);
  const onboardingService = new OnboardingService(profileRepo, planRepo, retirementRepo, protectionRepo);
  const planService = new PlanService(planRepo, eventsService);
  const retirementService = new RetirementService(retirementRepo, eventsService);
  const protectionService = new ProtectionService(protectionRepo, beneficiaryRepo, eventsService);

  const mockVaultProvider = new MockAvalancheAdapter();
  const realVaultProvider = new AvalancheAdapter(
    env.AVALANCHE_RPC_URL || '',
    env.AVALANCHE_CHAIN_ID,
    env.AVALANCHE_VAULT_ADDRESS || undefined,
    env.AVALANCHE_TIMEOUT_MS
  );

  const mockGenLayerProvider = new MockGenLayerAdapter();
  const realGenLayerProvider = new GenLayerAdapter(
    env.GENLAYER_API_URL || '',
    env.GENLAYER_TIMEOUT_MS,
    env.GENLAYER_FROM_ADDRESS || undefined,
    env.GENLAYER_CONTRACT_ADDRESS || undefined,
    env.GENLAYER_PROTECTION_CALL_DATA || undefined,
    env.GENLAYER_RETIREMENT_CALL_DATA || undefined,
    env.GENLAYER_PROOF_OF_LIFE_CALL_DATA || undefined
  );

  const integrationsService = new IntegrationsService(
    env.INTEGRATION_MODE,
    env.STORACHA_ENABLED,
    integrationStateRepo,
    eventsService,
    realVaultProvider,
    mockVaultProvider,
    realGenLayerProvider,
    mockGenLayerProvider
  );

  const storachaConfig = getStorachaConfig(process.env);
  const storachaAdapter = new StorachaAdapter(storachaConfig, console);
  const storachaService = new StorachaService(storachaAdapter, console);
  const retirementPassportService = new RetirementPassportService();
  const storachaArtifactsService = new StorachaArtifactsService(
    storachaService,
    retirementPassportService,
    artifactRepo,
    integrationStateRepo,
    profileRepo,
    planRepo,
    retirementRepo,
    protectionRepo,
    beneficiaryRepo,
    eventsService
  );

  const dashboardService = new DashboardService(
    authService,
    profileRepo,
    planRepo,
    retirementRepo,
    protectionRepo,
    beneficiaryRepo,
    integrationStateRepo,
    artifactRepo,
    eventsService,
    integrationsService
  );

  const container = {
    env,
    store,

    userRepo,
    sessionRepo,
    profileRepo,
    planRepo,
    retirementRepo,
    protectionRepo,
    beneficiaryRepo,
    eventRepo,
    integrationStateRepo,
    artifactRepo,

    authService,
    profileService,
    onboardingService,
    planService,
    retirementService,
    protectionService,
    eventsService,
    integrationsService,
    dashboardService,
    storachaConfig,
    storachaAdapter,
    storachaService,
    retirementPassportService,
    storachaArtifactsService
  };

  if (env.APP_MODE === 'demo') {
    seedDemo(container);
  }

  return container;
}
