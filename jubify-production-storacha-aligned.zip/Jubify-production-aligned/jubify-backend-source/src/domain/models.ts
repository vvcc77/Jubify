export type AuthType = 'demo' | 'email' | 'wallet';

export type RiskTolerance = 'conservative' | 'moderate' | 'aggressive';
export type ContributionFrequency = 'weekly' | 'monthly' | 'quarterly';
export type Currency = 'USD' | 'EUR' | 'ARS' | 'USDC';
export type StrategyType = 'conservative' | 'balanced' | 'growth';
export type PlanStatus = 'draft' | 'active' | 'paused';
export type RetirementMode = 'scheduled_income' | 'flex_withdrawal' | 'deferred_unlock';
export type ReleaseFrequency = 'monthly' | 'quarterly' | 'yearly';
export type EventType =
  | 'plan_created'
  | 'preference_updated'
  | 'contribution_registered'
  | 'retirement_configured'
  | 'protection_enabled'
  | 'inheritance_updated'
  | 'proof_of_life_updated'
  | 'external_sync_status'
  | 'artifact_archived';
export type EventSource = 'ui' | 'system' | 'avalanche' | 'genlayer' | 'mock' | 'storacha';
export type IntegrationProvider = 'avalanche' | 'genlayer' | 'storacha';
export type IntegrationStatus = 'healthy' | 'degraded' | 'offline';
export type ArtifactKind =
  | 'retirement_passport'
  | 'market_snapshot'
  | 'ai_decision'
  | 'liveness_record'
  | 'inheritance_instruction';

export interface User {
  id: string;
  authType: AuthType;
  email?: string;
  wallet?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Session {
  token: string;
  userId: string;
  expiresAt: string;
  createdAt: string;
}

export interface Profile {
  userId: string;
  riskTolerance: RiskTolerance;
  timeHorizon: string;
  preferences: string[];
  createdAt: string;
  updatedAt: string;
}

export interface SavingsPlan {
  id: string;
  userId: string;
  status: PlanStatus;
  contributionAmount: number;
  contributionFrequency: ContributionFrequency;
  currency: Currency;
  strategyType: StrategyType;
  createdAt: string;
  updatedAt: string;
}

export interface RetirementPlan {
  userId: string;
  mode: RetirementMode;
  lockPeriod: string;
  releaseFrequency: ReleaseFrequency;
  estimatedProjection: Record<string, unknown>;
  createdAt: string;
  updatedAt: string;
}

export interface ProtectionPlan {
  userId: string;
  protectionEnabled: boolean;
  inheritanceEnabled: boolean;
  proofOfLifeInterval: string;
  createdAt: string;
  updatedAt: string;
}

export interface Beneficiary {
  id: string;
  userId: string;
  name: string;
  destinationWalletOrAccount: string;
  percentage: number;
  createdAt: string;
  updatedAt: string;
}

export interface EventLog {
  id: string;
  userId: string;
  type: EventType;
  payload: Record<string, unknown>;
  source: EventSource;
  createdAt: string;
}

export interface IntegrationState {
  provider: IntegrationProvider;
  status: IntegrationStatus;
  lastSync: string | null;
  message: string | null;
}

export interface ArtifactRecord {
  id: string;
  userId: string;
  kind: ArtifactKind;
  provider: 'storacha';
  archived: boolean;
  checksumSha256: string;
  label: string;
  cid?: string;
  gatewayUrl?: string;
  errorCode?: string;
  errorMessage?: string;
  createdAt: string;
  updatedAt: string;
}

export interface VaultSummary {
  amount: number;
  currency: string;
  source: string;
  providerStatus: IntegrationStatus;
  providerMessage?: string;
  txReference?: string;
}

export interface ProviderActionResult {
  accepted: boolean;
  mode: 'simulated' | 'pending_signature' | 'unavailable';
  reference: string;
  message: string;
}

export interface IntegrationHealth {
  provider: IntegrationProvider;
  status: IntegrationStatus;
  message: string;
  checkedAt: string;
}

export interface ProtectionDecision {
  recommendedInterval: string;
  reason: string;
  source: string;
}

export interface RetirementGuidance {
  mode: string;
  releaseFrequency: string;
  note: string;
  source: string;
}

export interface ProofOfLifeResult {
  status: 'up_to_date' | 'pending' | 'expired';
  nextCheckAt: string;
  source: string;
}
