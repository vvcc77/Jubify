import type {
  ArtifactKind,
  ArtifactRecord,
  Beneficiary,
  EventLog,
  IntegrationProvider,
  IntegrationState,
  Profile,
  ProtectionPlan,
  RetirementPlan,
  SavingsPlan,
  Session,
  User
} from '../../domain/models';
import { MemoryStore } from './store';

export class UserRepository {
  constructor(private readonly store: MemoryStore) {}

  findById(id: string): User | undefined {
    return this.store.users.get(id);
  }

  findByEmail(email: string): User | undefined {
    return Array.from(this.store.users.values()).find((user) => user.email === email);
  }

  findByWallet(wallet: string): User | undefined {
    return Array.from(this.store.users.values()).find((user) => user.wallet?.toLowerCase() === wallet.toLowerCase());
  }

  upsert(user: User): User {
    this.store.users.set(user.id, user);
    return user;
  }
}

export class SessionRepository {
  constructor(private readonly store: MemoryStore) {}

  save(session: Session): Session {
    this.store.sessions.set(session.token, session);
    return session;
  }

  findByToken(token: string): Session | undefined {
    return this.store.sessions.get(token);
  }

  deleteExpired(nowIso: string): void {
    for (const [token, session] of this.store.sessions.entries()) {
      if (new Date(session.expiresAt).getTime() <= new Date(nowIso).getTime()) {
        this.store.sessions.delete(token);
      }
    }
  }
}

export class ProfileRepository {
  constructor(private readonly store: MemoryStore) {}

  findByUserId(userId: string): Profile | undefined {
    return this.store.profiles.get(userId);
  }

  save(profile: Profile): Profile {
    this.store.profiles.set(profile.userId, profile);
    return profile;
  }
}

export class PlanRepository {
  constructor(private readonly store: MemoryStore) {}

  findByUserId(userId: string): SavingsPlan | undefined {
    return this.store.plans.get(userId);
  }

  save(plan: SavingsPlan): SavingsPlan {
    this.store.plans.set(plan.userId, plan);
    return plan;
  }
}

export class RetirementRepository {
  constructor(private readonly store: MemoryStore) {}

  findByUserId(userId: string): RetirementPlan | undefined {
    return this.store.retirements.get(userId);
  }

  save(plan: RetirementPlan): RetirementPlan {
    this.store.retirements.set(plan.userId, plan);
    return plan;
  }
}

export class ProtectionRepository {
  constructor(private readonly store: MemoryStore) {}

  findByUserId(userId: string): ProtectionPlan | undefined {
    return this.store.protections.get(userId);
  }

  save(plan: ProtectionPlan): ProtectionPlan {
    this.store.protections.set(plan.userId, plan);
    return plan;
  }
}

export class BeneficiaryRepository {
  constructor(private readonly store: MemoryStore) {}

  findByUserId(userId: string): Beneficiary[] {
    return this.store.beneficiaries.get(userId) ?? [];
  }

  replaceForUser(userId: string, items: Beneficiary[]): Beneficiary[] {
    this.store.beneficiaries.set(userId, items);
    return items;
  }
}

export class EventLogRepository {
  constructor(private readonly store: MemoryStore) {}

  add(event: EventLog): EventLog {
    const current = this.store.events.get(event.userId) ?? [];
    current.unshift(event);
    this.store.events.set(event.userId, current);
    return event;
  }

  listByUser(userId: string, limit = 20, type?: string): EventLog[] {
    const items = this.store.events.get(userId) ?? [];
    const filtered = type ? items.filter((item) => item.type === type) : items;
    return filtered.slice(0, limit);
  }
}

export class IntegrationStateRepository {
  constructor(private readonly store: MemoryStore) {}

  get(provider: IntegrationProvider): IntegrationState | undefined {
    return this.store.integrationStates.get(provider);
  }

  upsert(state: IntegrationState): IntegrationState {
    this.store.integrationStates.set(state.provider, state);
    return state;
  }

  list(): IntegrationState[] {
    return Array.from(this.store.integrationStates.values());
  }
}

export class ArtifactRepository {
  constructor(private readonly store: MemoryStore) {}

  upsert(record: ArtifactRecord): ArtifactRecord {
    const current = this.store.artifacts.get(record.userId) ?? [];
    const next = current.filter((item) => item.kind !== record.kind);
    next.unshift(record);
    this.store.artifacts.set(record.userId, next);
    return record;
  }

  listByUser(userId: string): ArtifactRecord[] {
    return this.store.artifacts.get(userId) ?? [];
  }

  findLatest(userId: string, kind: ArtifactKind): ArtifactRecord | undefined {
    return (this.store.artifacts.get(userId) ?? []).find((item) => item.kind === kind);
  }
}
