import type {
  ArtifactRecord,
  Beneficiary,
  EventLog,
  IntegrationState,
  Profile,
  ProtectionPlan,
  RetirementPlan,
  SavingsPlan,
  Session,
  User
} from '../../domain/models';

export class MemoryStore {
  users = new Map<string, User>();
  sessions = new Map<string, Session>();
  profiles = new Map<string, Profile>();
  plans = new Map<string, SavingsPlan>();
  retirements = new Map<string, RetirementPlan>();
  protections = new Map<string, ProtectionPlan>();
  beneficiaries = new Map<string, Beneficiary[]>();
  events = new Map<string, EventLog[]>();
  integrationStates = new Map<string, IntegrationState>();
  artifacts = new Map<string, ArtifactRecord[]>();
}
