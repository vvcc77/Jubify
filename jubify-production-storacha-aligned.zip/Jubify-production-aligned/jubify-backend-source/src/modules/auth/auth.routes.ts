import type { FastifyInstance } from 'fastify';
import { ok } from '../../shared/http/response';
import { parseWithSchema } from '../../shared/http/validation';
import { createRateLimit } from '../../shared/http/rate-limit';
import { demoLoginSchema, emailLoginSchema, walletConnectSchema } from './auth.schemas';

export async function authRoutes(app: FastifyInstance): Promise<void> {
  const authRateLimit = createRateLimit(
    app.container.env.RATE_LIMIT_WINDOW_MS,
    app.container.env.RATE_LIMIT_AUTH_MAX
  );

  app.post('/auth/demo-login', { preHandler: authRateLimit }, async (request, reply) => {
    parseWithSchema(demoLoginSchema, request.body);
    const result = app.container.authService.demoLogin();
    ok(request, reply, result, { mode: app.container.env.INTEGRATION_MODE });
  });

  app.post('/auth/email-login', { preHandler: authRateLimit }, async (request, reply) => {
    const body = parseWithSchema(emailLoginSchema, request.body);
    const result = app.container.authService.emailLogin(body.email);
    ok(request, reply, result, { mode: app.container.env.INTEGRATION_MODE });
  });

  app.post('/auth/wallet-connect', { preHandler: authRateLimit }, async (request, reply) => {
    const body = parseWithSchema(walletConnectSchema, request.body);
    const result = app.container.authService.walletConnect(body.wallet);
    ok(request, reply, result, { mode: app.container.env.INTEGRATION_MODE });
  });
}
