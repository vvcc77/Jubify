import { z } from 'zod';

export const demoLoginSchema = z.object({
  demoUser: z.string().default('default')
});

export const emailLoginSchema = z.object({
  email: z.string().email()
});

export const walletConnectSchema = z.object({
  wallet: z.string().min(10).max(128),
  signature: z.string().optional()
});
