import { randomBytes } from 'node:crypto';
import type { Session, User } from '../../domain/models';
import { SessionRepository, UserRepository } from '../../infra/memory/repositories';
import { AppError } from '../../shared/errors/app-error';
import { addHours, nowIso } from '../../shared/utils/dates';
import { createId } from '../../shared/utils/ids';

type AuthResult = {
  user: User;
  session: {
    accessToken: string;
    expiresIn: number;
  };
};

export class AuthService {
  constructor(
    private readonly userRepo: UserRepository,
    private readonly sessionRepo: SessionRepository,
    private readonly sessionTtlHours: number
  ) {}

  demoLogin(): AuthResult {
    const existing = this.userRepo.findById('usr_demo_001');
    const user =
      existing ??
      this.userRepo.upsert({
        id: 'usr_demo_001',
        authType: 'demo',
        email: 'demo@jubify.app',
        createdAt: nowIso(),
        updatedAt: nowIso()
      });

    return this.issueSession(user);
  }

  emailLogin(email: string): AuthResult {
    const existing = this.userRepo.findByEmail(email);
    const user =
      existing ??
      this.userRepo.upsert({
        id: createId('usr'),
        authType: 'email',
        email,
        createdAt: nowIso(),
        updatedAt: nowIso()
      });

    return this.issueSession(user);
  }

  walletConnect(wallet: string): AuthResult {
    const existing = this.userRepo.findByWallet(wallet);
    const user =
      existing ??
      this.userRepo.upsert({
        id: createId('usr'),
        authType: 'wallet',
        wallet,
        createdAt: nowIso(),
        updatedAt: nowIso()
      });

    return this.issueSession(user);
  }

  verifySession(token: string): Session {
    this.sessionRepo.deleteExpired(nowIso());
    const session = this.sessionRepo.findByToken(token);
    if (!session) {
      throw AppError.unauthorized('Invalid or expired session');
    }
    return session;
  }

  getUser(userId: string): User {
    const user = this.userRepo.findById(userId);
    if (!user) {
      throw AppError.notFound('User not found');
    }
    return user;
  }

  private issueSession(user: User): AuthResult {
    const issuedAt = nowIso();
    const token = `jub_${randomBytes(24).toString('hex')}`;
    const expiresAt = addHours(issuedAt, this.sessionTtlHours);

    this.sessionRepo.save({
      token,
      userId: user.id,
      createdAt: issuedAt,
      expiresAt
    });

    return {
      user,
      session: {
        accessToken: token,
        expiresIn: this.sessionTtlHours * 60 * 60
      }
    };
  }
}
