import type { FastifyInstance } from 'fastify';
import { assertUserAccess, requireAuth } from '../../shared/http/auth-guard';
import { ok } from '../../shared/http/response';
import { parseWithSchema } from '../../shared/http/validation';
import { userIdParamsSchema } from '../plan/plan.schemas';

export async function dashboardRoutes(app: FastifyInstance): Promise<void> {
  app.get('/dashboard/:userId', { preHandler: requireAuth }, async (request, reply) => {
    const params = parseWithSchema(userIdParamsSchema, request.params);
    assertUserAccess(request, params.userId);
    const dashboard = await app.container.dashboardService.getDashboard(params.userId);
    ok(request, reply, dashboard, { mode: app.container.env.INTEGRATION_MODE });
  });
}
