import { AppError } from '../../shared/errors/app-error';
import { nextContributionAt, nextReleaseAt, nowIso } from '../../shared/utils/dates';
import {
  ArtifactRepository,
  BeneficiaryRepository,
  IntegrationStateRepository,
  PlanRepository,
  ProfileRepository,
  ProtectionRepository,
  RetirementRepository
} from '../../infra/memory/repositories';
import { AuthService } from '../auth/auth.service';
import { EventsService } from '../events/events.service';
import { IntegrationsService } from '../integrations/integrations.service';

export class DashboardService {
  constructor(
    private readonly authService: AuthService,
    private readonly profileRepo: ProfileRepository,
    private readonly planRepo: PlanRepository,
    private readonly retirementRepo: RetirementRepository,
    private readonly protectionRepo: ProtectionRepository,
    private readonly beneficiaryRepo: BeneficiaryRepository,
    private readonly integrationStateRepo: IntegrationStateRepository,
    private readonly artifactRepo: ArtifactRepository,
    private readonly eventsService: EventsService,
    private readonly integrationsService: IntegrationsService
  ) {}

  async getByUserId(userId: string) {
    const user = this.authService.getUserById(userId);
    if (!user) {
      throw AppError.notFound('User not found');
    }

    const profile = this.profileRepo.findByUserId(userId);
    const plan = this.planRepo.findByUserId(userId);
    const retirement = this.retirementRepo.findByUserId(userId);
    const protection = this.protectionRepo.findByUserId(userId);
    const beneficiaries = this.beneficiaryRepo.findByUserId(userId);
    const artifactList = this.artifactRepo.listByUser(userId);

    if (!plan) {
      throw AppError.notFound('Plan not found');
    }

    const balance = await this.integrationsService.getVaultSummary(user);
    const statuses = await this.integrationsService.getStatuses();
    const states = statuses.reduce<Record<string, string>>((acc, item) => {
      acc[item.provider] = item.status;
      return acc;
    }, {});

    const proofOfLife = await this.integrationsService.getGenLayerProofOfLife(user);
    const retirementGuidance = await this.integrationsService.getGenLayerRetirementGuidance(user);

    return {
      user: {
        id: user.id,
        authType: user.authType,
        email: user.email,
        wallet: user.wallet
      },
      profile: profile ?? null,
      plan,
      balance,
      nextContribution: {
        dueAt: nextContributionAt(plan.updatedAt ?? nowIso(), plan.contributionFrequency),
        amount: plan.contributionAmount,
        currency: plan.currency
      },
      retirement: retirement
        ? {
            configured: true,
            mode: retirement.mode,
            releaseFrequency: retirement.releaseFrequency,
            nextReleaseAt: nextReleaseAt(retirement.updatedAt ?? nowIso(), retirement.releaseFrequency),
            guidance: retirementGuidance
          }
        : {
            configured: false
          },
      inheritance: {
        configured: Boolean(protection?.inheritanceEnabled),
        beneficiariesCount: beneficiaries.length
      },
      protection: protection
        ? {
            protectionEnabled: protection.protectionEnabled,
            proofOfLifeInterval: protection.proofOfLifeInterval,
            proofOfLife
          }
        : null,
      integrations: {
        avalanche: states.avalanche ?? 'offline',
        genlayer: states.genlayer ?? 'offline',
        storacha: states.storacha ?? 'offline'
      },
      storacha: {
        artifacts: artifactList.map((item) => ({
          kind: item.kind,
          archived: item.archived,
          cid: item.cid,
          gatewayUrl: item.gatewayUrl,
          updatedAt: item.updatedAt,
          errorCode: item.errorCode,
          errorMessage: item.errorMessage
        }))
      },
      upcomingEvents: [
        {
          type: 'next_contribution',
          at: nextContributionAt(plan.updatedAt ?? nowIso(), plan.contributionFrequency)
        },
        retirement
          ? {
              type: 'next_release',
              at: nextReleaseAt(retirement.updatedAt ?? nowIso(), retirement.releaseFrequency)
            }
          : null
      ].filter(Boolean),
      timeline: this.eventsService.list(userId, 8)
    };
  }
}
