import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { assertUserAccess, requireAuth } from '../../shared/http/auth-guard';
import { ok } from '../../shared/http/response';
import { parseWithSchema } from '../../shared/http/validation';
import { userIdParamsSchema } from '../plan/plan.schemas';

const eventsQuerySchema = z.object({
  limit: z.coerce.number().int().positive().max(100).optional(),
  type: z.string().optional()
});

export async function eventsRoutes(app: FastifyInstance): Promise<void> {
  app.get('/plan/:userId/events', { preHandler: requireAuth }, async (request, reply) => {
    const params = parseWithSchema(userIdParamsSchema, request.params);
    const query = parseWithSchema(eventsQuerySchema, request.query);
    assertUserAccess(request, params.userId);

    const items = app.container.eventsService.list(params.userId, query.limit ?? 20, query.type);
    ok(request, reply, {
      items,
      nextCursor: null
    }, { mode: app.container.env.INTEGRATION_MODE });
  });
}
