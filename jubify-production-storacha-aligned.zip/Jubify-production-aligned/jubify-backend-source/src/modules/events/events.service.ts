import type { EventLog, EventSource, EventType } from '../../domain/models';
import { EventLogRepository } from '../../infra/memory/repositories';
import { createId } from '../../shared/utils/ids';
import { nowIso } from '../../shared/utils/dates';

export class EventsService {
  constructor(private readonly eventRepo: EventLogRepository) {}

  record(userId: string, type: EventType, payload: Record<string, unknown>, source: EventSource): EventLog {
    return this.eventRepo.add({
      id: createId('evt'),
      userId,
      type,
      payload,
      source,
      createdAt: nowIso()
    });
  }

  list(userId: string, limit = 20, type?: string): EventLog[] {
    return this.eventRepo.listByUser(userId, limit, type);
  }
}
