import type { IntegrationHealth, ProviderActionResult, User, VaultSummary } from '../../../domain/models';
import { AppError } from '../../../shared/errors/app-error';
import { nowIso } from '../../../shared/utils/dates';
import { createId } from '../../../shared/utils/ids';
import type { VaultProviderPort } from '../ports/vault-provider.port';

type JsonRpcResponse<T> = {
  result?: T;
  error?: {
    code: number;
    message: string;
  };
};

export class AvalancheAdapter implements VaultProviderPort {
  constructor(
    private readonly rpcUrl: string,
    private readonly chainId: string,
    private readonly vaultAddress?: string,
    private readonly timeoutMs = 3500
  ) {}

  async getVaultSummary(user: User): Promise<VaultSummary> {
    this.assertConfigured();
    const address = user.wallet || this.vaultAddress;
    if (!address) {
      throw AppError.integration('Avalanche adapter missing wallet and vault address');
    }

    const result = await this.rpcCall<string>('eth_getBalance', [address, 'latest']);
    const balanceWei = result ?? '0x0';
    const numeric = Number.parseInt(balanceWei, 16);
    const normalized = Number.isFinite(numeric) ? numeric / 1_000_000_000_000_000_000 : 0;

    return {
      amount: Number(normalized.toFixed(6)),
      currency: 'AVAX',
      source: 'avalanche_rpc',
      providerStatus: 'healthy',
      providerMessage: `Fetched from ${address}`
    };
  }

  async simulateContribution(_user: User, amount: number, currency: string): Promise<ProviderActionResult> {
    this.assertConfigured();
    return {
      accepted: true,
      mode: 'pending_signature',
      reference: createId('avax_pending'),
      message: `Contribution intent prepared for client-side signature: ${amount} ${currency}`
    };
  }

  async simulateRedemption(_user: User, amount: number, currency: string): Promise<ProviderActionResult> {
    this.assertConfigured();
    return {
      accepted: true,
      mode: 'pending_signature',
      reference: createId('avax_pending'),
      message: `Redemption intent prepared for client-side signature: ${amount} ${currency}`
    };
  }

  async getHealth(): Promise<IntegrationHealth> {
    this.assertConfigured();
    const chainIdHex = await this.rpcCall<string>('eth_chainId', []);
    const parsedChainId = chainIdHex ? Number.parseInt(chainIdHex, 16).toString() : 'unknown';
    const healthy = parsedChainId === this.chainId;

    return {
      provider: 'avalanche',
      status: healthy ? 'healthy' : 'degraded',
      message: healthy
        ? `Avalanche RPC reachable on chain ${parsedChainId}`
        : `Avalanche RPC reachable but chain mismatch (expected ${this.chainId}, got ${parsedChainId})`,
      checkedAt: nowIso()
    };
  }

  private async rpcCall<T>(method: string, params: unknown[]): Promise<T | undefined> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await fetch(this.rpcUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          id: 1,
          method,
          params
        }),
        signal: controller.signal
      });

      if (!response.ok) {
        throw AppError.integration(`Avalanche RPC HTTP ${response.status}`);
      }

      const payload = (await response.json()) as JsonRpcResponse<T>;
      if (payload.error) {
        throw AppError.integration(`Avalanche RPC error: ${payload.error.message}`);
      }

      return payload.result;
    } catch (error) {
      if (error instanceof AppError) {
        throw error;
      }
      throw AppError.integration('Avalanche RPC unavailable');
    } finally {
      clearTimeout(timeout);
    }
  }

  private assertConfigured(): void {
    if (!this.rpcUrl) {
      throw AppError.integration('Avalanche RPC URL is not configured');
    }
  }
}
