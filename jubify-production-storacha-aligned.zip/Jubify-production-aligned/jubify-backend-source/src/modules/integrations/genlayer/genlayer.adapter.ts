import type {
  IntegrationHealth,
  ProofOfLifeResult,
  ProtectionDecision,
  RetirementGuidance,
  User
} from '../../../domain/models';
import { AppError } from '../../../shared/errors/app-error';
import { nowIso } from '../../../shared/utils/dates';
import type { IntelligentContractPort } from '../ports/intelligent-contract.port';

type GenCallResponse = {
  result?: {
    status?: {
      code?: number;
      message?: string;
    };
    data?: string;
  };
  error?: {
    code: number;
    message: string;
  };
};

export class GenLayerAdapter implements IntelligentContractPort {
  constructor(
    private readonly apiUrl: string,
    private readonly timeoutMs: number,
    private readonly fromAddress?: string,
    private readonly contractAddress?: string,
    private readonly protectionCallData?: string,
    private readonly retirementCallData?: string,
    private readonly proofOfLifeCallData?: string
  ) {}

  async getProtectionDecision(_user: User): Promise<ProtectionDecision> {
    const result = await this.callRead(this.protectionCallData);
    return {
      recommendedInterval: '90d',
      reason: result,
      source: 'genlayer_node'
    };
  }

  async getRetirementRecommendation(_user: User): Promise<RetirementGuidance> {
    const result = await this.callRead(this.retirementCallData);
    return {
      mode: 'scheduled_income',
      releaseFrequency: 'monthly',
      note: result,
      source: 'genlayer_node'
    };
  }

  async simulateProofOfLifeCheck(_user: User): Promise<ProofOfLifeResult> {
    const result = await this.callRead(this.proofOfLifeCallData);
    return {
      status: 'up_to_date',
      nextCheckAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 90).toISOString(),
      source: `genlayer_node:${result}`
    };
  }

  async getHealth(): Promise<IntegrationHealth> {
    this.assertBaseUrl();
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await fetch(new URL('/health', this.apiUrl), {
        method: 'GET',
        signal: controller.signal
      });

      const body = await response.json() as Record<string, unknown>;
      const status = response.ok && body.status === 'up' ? 'healthy' : 'degraded';

      return {
        provider: 'genlayer',
        status,
        message: response.ok ? 'GenLayer health endpoint reachable' : 'GenLayer health endpoint degraded',
        checkedAt: nowIso()
      };
    } catch (_error) {
      throw AppError.integration('GenLayer API unavailable');
    } finally {
      clearTimeout(timeout);
    }
  }

  private async callRead(callData?: string): Promise<string> {
    this.assertBaseUrl();

    if (!this.fromAddress || !this.contractAddress || !callData) {
      throw AppError.integration('GenLayer read call is not fully configured');
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          id: 1,
          method: 'gen_call',
          params: [
            {
              Type: 'read',
              Data: callData,
              from: this.fromAddress,
              to: this.contractAddress
            }
          ]
        }),
        signal: controller.signal
      });

      if (!response.ok) {
        throw AppError.integration(`GenLayer HTTP ${response.status}`);
      }

      const payload = (await response.json()) as GenCallResponse;
      if (payload.error) {
        throw AppError.integration(`GenLayer RPC error: ${payload.error.message}`);
      }

      const message = payload.result?.status?.message ?? 'success';
      const data = payload.result?.data ?? '0x';
      return `${message}:${data}`;
    } catch (error) {
      if (error instanceof AppError) {
        throw error;
      }
      throw AppError.integration('GenLayer RPC unavailable');
    } finally {
      clearTimeout(timeout);
    }
  }

  private assertBaseUrl(): void {
    if (!this.apiUrl) {
      throw AppError.integration('GenLayer API URL is not configured');
    }
  }
}
