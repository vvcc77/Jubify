import type { FastifyInstance } from 'fastify';
import { createRateLimit } from '../../shared/http/rate-limit';
import { ok } from '../../shared/http/response';

export async function integrationsRoutes(app: FastifyInstance): Promise<void> {
  const publicRateLimit = createRateLimit(
    app.container.env.RATE_LIMIT_WINDOW_MS,
    app.container.env.RATE_LIMIT_PUBLIC_MAX
  );

  app.get('/health', { preHandler: publicRateLimit }, async (request, reply) => {
    const statuses = await app.container.integrationsService.getStatuses();
    const allHealthy = statuses.every((item) => item.status === 'healthy');

    ok(request, reply, {
      status: allHealthy ? 'ok' : 'degraded',
      app: 'healthy',
      integrations: statuses
    }, { mode: app.container.env.INTEGRATION_MODE });
  });

  app.get('/integrations/status', { preHandler: publicRateLimit }, async (request, reply) => {
    const providers = await app.container.integrationsService.getStatuses();
    ok(request, reply, { providers }, { mode: app.container.env.INTEGRATION_MODE });
  });
}
