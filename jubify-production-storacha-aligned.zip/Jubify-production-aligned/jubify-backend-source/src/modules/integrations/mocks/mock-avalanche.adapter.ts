import type { IntegrationHealth, ProviderActionResult, User, VaultSummary } from '../../../domain/models';
import { nowIso } from '../../../shared/utils/dates';
import { createId } from '../../../shared/utils/ids';
import type { VaultProviderPort } from '../ports/vault-provider.port';

export class MockAvalancheAdapter implements VaultProviderPort {
  async getVaultSummary(user: User): Promise<VaultSummary> {
    const base = user.id === 'usr_demo_001' ? 1250 : 420;
    return {
      amount: base,
      currency: 'USDC',
      source: 'mock_avalanche',
      providerStatus: 'healthy',
      providerMessage: 'Mock Avalanche adapter active'
    };
  }

  async simulateContribution(_user: User, amount: number, currency: string): Promise<ProviderActionResult> {
    return {
      accepted: true,
      mode: 'simulated',
      reference: createId('avax_mock_tx'),
      message: `Mock contribution registered: ${amount} ${currency}`
    };
  }

  async simulateRedemption(_user: User, amount: number, currency: string): Promise<ProviderActionResult> {
    return {
      accepted: true,
      mode: 'simulated',
      reference: createId('avax_mock_tx'),
      message: `Mock redemption registered: ${amount} ${currency}`
    };
  }

  async getHealth(): Promise<IntegrationHealth> {
    return {
      provider: 'avalanche',
      status: 'healthy',
      message: 'Mock Avalanche healthy',
      checkedAt: nowIso()
    };
  }
}
