import type {
  IntegrationHealth,
  ProofOfLifeResult,
  ProtectionDecision,
  RetirementGuidance,
  User
} from '../../../domain/models';
import { addDays, nowIso } from '../../../shared/utils/dates';
import type { IntelligentContractPort } from '../ports/intelligent-contract.port';

export class MockGenLayerAdapter implements IntelligentContractPort {
  async getProtectionDecision(_user: User): Promise<ProtectionDecision> {
    return {
      recommendedInterval: '90d',
      reason: 'Mock recommendation based on conservative demo defaults',
      source: 'mock_genlayer'
    };
  }

  async getRetirementRecommendation(_user: User): Promise<RetirementGuidance> {
    return {
      mode: 'scheduled_income',
      releaseFrequency: 'monthly',
      note: 'Mock recommendation for stable withdrawal rhythm',
      source: 'mock_genlayer'
    };
  }

  async simulateProofOfLifeCheck(_user: User): Promise<ProofOfLifeResult> {
    const now = nowIso();
    return {
      status: 'up_to_date',
      nextCheckAt: addDays(now, 90),
      source: 'mock_genlayer'
    };
  }

  async getHealth(): Promise<IntegrationHealth> {
    return {
      provider: 'genlayer',
      status: 'healthy',
      message: 'Mock GenLayer healthy',
      checkedAt: nowIso()
    };
  }
}
