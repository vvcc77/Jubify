import type {
  IntegrationHealth,
  ProofOfLifeResult,
  ProtectionDecision,
  RetirementGuidance,
  User
} from '../../../domain/models';

export interface IntelligentContractPort {
  getProtectionDecision(user: User): Promise<ProtectionDecision>;
  getRetirementRecommendation(user: User): Promise<RetirementGuidance>;
  simulateProofOfLifeCheck(user: User): Promise<ProofOfLifeResult>;
  getHealth(): Promise<IntegrationHealth>;
}
