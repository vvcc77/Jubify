import type { IntegrationHealth, ProviderActionResult, User, VaultSummary } from '../../../domain/models';

export interface VaultProviderPort {
  getVaultSummary(user: User): Promise<VaultSummary>;
  simulateContribution(user: User, amount: number, currency: string): Promise<ProviderActionResult>;
  simulateRedemption(user: User, amount: number, currency: string): Promise<ProviderActionResult>;
  getHealth(): Promise<IntegrationHealth>;
}
