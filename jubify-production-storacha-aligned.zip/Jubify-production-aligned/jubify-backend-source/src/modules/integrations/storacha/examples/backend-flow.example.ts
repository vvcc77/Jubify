/**
 * Example only.
 * This file shows how to hook Storacha into the existing JUBIFY backend flow
 * without turning Storacha into the source of truth.
 */

import { RetirementPassportService } from '../../../passport/retirement-passport.service';
import { StorachaService } from '../storacha.service';

interface VaultArtifactWriter {
  setProfileCID(userAddress: string, cid: string): Promise<void>;
  setDecisionCID(userAddress: string, cid: string): Promise<void>;
  setLivenessCID(userAddress: string, cid: string): Promise<void>;
}

export class JubifyStorachaFlowExample {
  constructor(
    private readonly passportService: RetirementPassportService,
    private readonly storachaService: StorachaService,
    private readonly vaultArtifactWriter: VaultArtifactWriter,
    private readonly writeOnChain: boolean,
  ) {}

  async archivePassportAndMaybeWriteCid(input: {
    userRef: string;
    userAddress: string;
    profile: {
      riskTolerance: 'conservative' | 'moderate' | 'aggressive';
      timeHorizonYears: number;
      preferences: string[];
    };
    plan: {
      contributionAmount: number;
      contributionFrequency: 'weekly' | 'monthly' | 'quarterly';
      currency: string;
      strategyType: 'conservative' | 'balanced' | 'growth';
    };
    retirement: {
      mode: 'scheduled_income' | 'flex_withdrawal' | 'deferred_unlock';
      lockPeriod: string;
      releaseFrequency: 'monthly' | 'quarterly' | 'yearly';
    };
  }) {
    const passport = this.passportService.build({
      userRef: input.userRef,
      profile: input.profile,
      plan: input.plan,
      retirement: input.retirement,
    });

    const archive = await this.storachaService.archiveRetirementPassportSafely(passport);

    // Always persist archive result in backend first.
    // Example database fields:
    // - archive.provider
    // - archive.cid
    // - archive.gatewayUrl
    // - archive.checksumSha256
    // - archive.archived
    // - archive.errorCode
    // - archive.errorMessage

    if (archive.archived && archive.cid && this.writeOnChain) {
      await this.vaultArtifactWriter.setProfileCID(input.userAddress, archive.cid);
    }

    return archive;
  }
}
