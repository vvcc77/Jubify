import type { ArtifactKind, ArtifactRecord, Beneficiary, Profile, RetirementPlan, SavingsPlan } from '../../../domain/models';
import {
  ArtifactRepository,
  BeneficiaryRepository,
  IntegrationStateRepository,
  PlanRepository,
  ProfileRepository,
  ProtectionRepository,
  RetirementRepository
} from '../../../infra/memory/repositories';
import { nowIso } from '../../../shared/utils/dates';
import { createId } from '../../../shared/utils/ids';
import { EventsService } from '../../events/events.service';
import { RetirementPassportService } from '../../passport/retirement-passport.service';
import type { AIDecision, InheritanceInstruction, LivenessRecord, MarketSnapshot, StorachaUploadResult } from './storacha.types';
import { StorachaService } from './storacha.service';

function parseTimeHorizonYears(raw: string): number {
  const match = raw.match(/(\d+)/);
  return match ? Number(match[1]) : 10;
}

function toArtifactRecord(userId: string, result: StorachaUploadResult): ArtifactRecord {
  const timestamp = nowIso();
  return {
    id: createId('art'),
    userId,
    kind: result.kind,
    provider: 'storacha',
    archived: result.archived,
    checksumSha256: result.checksumSha256,
    label: result.label,
    cid: result.cid,
    gatewayUrl: result.gatewayUrl,
    errorCode: result.errorCode,
    errorMessage: result.errorMessage,
    createdAt: timestamp,
    updatedAt: timestamp
  };
}

export class StorachaArtifactsService {
  constructor(
    private readonly storachaService: StorachaService,
    private readonly passportService: RetirementPassportService,
    private readonly artifactRepo: ArtifactRepository,
    private readonly integrationStateRepo: IntegrationStateRepository,
    private readonly profileRepo: ProfileRepository,
    private readonly planRepo: PlanRepository,
    private readonly retirementRepo: RetirementRepository,
    private readonly protectionRepo: ProtectionRepository,
    private readonly beneficiaryRepo: BeneficiaryRepository,
    private readonly eventsService: EventsService
  ) {}

  listArtifacts(userId: string): ArtifactRecord[] {
    return this.artifactRepo.listByUser(userId);
  }

  async archivePassportIfReady(userId: string): Promise<ArtifactRecord | null> {
    const profile = this.profileRepo.findByUserId(userId);
    const plan = this.planRepo.findByUserId(userId);
    const retirement = this.retirementRepo.findByUserId(userId);

    if (!profile || !plan || !retirement) {
      return null;
    }

    const passport = this.buildPassport(userId, profile, plan, retirement);
    const result = await this.storachaService.archiveRetirementPassportSafely(passport);
    return this.persistResult(userId, result, {
      artifact: 'retirement_passport',
      messageSuccess: 'Retirement passport archived to Storacha',
      messageFailure: 'Retirement passport archive failed'
    });
  }

  async archiveMarketSnapshot(userId: string, snapshot: MarketSnapshot): Promise<ArtifactRecord> {
    const result = await this.storachaService.archiveMarketSnapshot(snapshot);
    return this.persistResult(userId, result, {
      artifact: 'market_snapshot',
      messageSuccess: 'Market snapshot archived to Storacha',
      messageFailure: 'Market snapshot archive failed'
    });
  }

  async archiveAiDecision(userId: string, decision: AIDecision): Promise<ArtifactRecord> {
    const result = await this.storachaService.archiveAiDecision(userId, decision);
    return this.persistResult(userId, result, {
      artifact: 'ai_decision',
      messageSuccess: 'AI decision archived to Storacha',
      messageFailure: 'AI decision archive failed'
    });
  }

  async archiveLivenessRecord(record: LivenessRecord): Promise<ArtifactRecord> {
    const result = await this.storachaService.archiveLivenessRecord(record);
    return this.persistResult(record.userRef, result, {
      artifact: 'liveness_record',
      messageSuccess: 'Liveness record archived to Storacha',
      messageFailure: 'Liveness record archive failed'
    });
  }

  async archiveInheritanceIfReady(userId: string): Promise<ArtifactRecord | null> {
    const protection = this.protectionRepo.findByUserId(userId);
    const beneficiaries = this.beneficiaryRepo.findByUserId(userId);

    if (!protection?.inheritanceEnabled || beneficiaries.length === 0) {
      return null;
    }

    const instruction: InheritanceInstruction = {
      version: '1.0',
      userRef: userId,
      mode: 'sanitized',
      beneficiaries: beneficiaries.map((item) => ({
        destination: item.destinationWalletOrAccount,
        percentageBps: Math.round(item.percentage * 100),
        alias: item.name
      })),
      generatedAt: nowIso()
    };

    const result = await this.storachaService.archiveInheritanceInstruction(instruction);
    return this.persistResult(userId, result, {
      artifact: 'inheritance_instruction',
      messageSuccess: 'Inheritance instruction archived to Storacha',
      messageFailure: 'Inheritance instruction archive failed'
    });
  }

  private buildPassport(
    userId: string,
    profile: Profile,
    plan: SavingsPlan,
    retirement: RetirementPlan
  ) {
    return this.passportService.build({
      userRef: userId,
      profile: {
        riskTolerance: profile.riskTolerance,
        timeHorizonYears: parseTimeHorizonYears(profile.timeHorizon),
        preferences: profile.preferences
      },
      plan: {
        contributionAmount: plan.contributionAmount,
        contributionFrequency: plan.contributionFrequency,
        currency: plan.currency,
        strategyType: plan.strategyType
      },
      retirement: {
        mode: retirement.mode,
        lockPeriod: retirement.lockPeriod,
        releaseFrequency: retirement.releaseFrequency
      }
    });
  }

  private persistResult(
    userId: string,
    result: StorachaUploadResult,
    messages: { artifact: ArtifactKind; messageSuccess: string; messageFailure: string }
  ): ArtifactRecord {
    const record = this.artifactRepo.upsert(toArtifactRecord(userId, result));
    const status = result.archived ? 'healthy' : 'degraded';
    const message = result.archived
      ? `${messages.messageSuccess}${result.cid ? ` (${result.cid})` : ''}`
      : `${messages.messageFailure}${result.errorMessage ? `: ${result.errorMessage}` : ''}`;

    this.integrationStateRepo.upsert({
      provider: 'storacha',
      status,
      lastSync: nowIso(),
      message
    });

    this.eventsService.record(userId, 'artifact_archived', {
      kind: messages.artifact,
      archived: result.archived,
      cid: result.cid,
      gatewayUrl: result.gatewayUrl,
      errorCode: result.errorCode,
      errorMessage: result.errorMessage
    }, 'storacha');

    this.eventsService.record(userId, 'external_sync_status', {
      provider: 'storacha',
      status,
      message
    }, 'storacha');

    return record;
  }
}
