import { createHash } from 'node:crypto';
import type { JsonObject, JsonValue, StorachaConfig, StorachaUploadRequest, StorachaUploadResult } from './storacha.types';

export interface MinimalLogger {
  info?(payload: unknown, message?: string): void;
  warn?(payload: unknown, message?: string): void;
  error?(payload: unknown, message?: string): void;
}

function sortJson(value: JsonValue): JsonValue {
  if (Array.isArray(value)) {
    return value.map(sortJson);
  }

  if (value !== null && typeof value === 'object') {
    const sorted: JsonObject = {};
    for (const key of Object.keys(value).sort()) {
      sorted[key] = sortJson((value as JsonObject)[key]);
    }
    return sorted;
  }

  return value;
}

function canonicalStringify(payload: JsonObject): string {
  return JSON.stringify(sortJson(payload));
}

function sha256Hex(content: string): string {
  return createHash('sha256').update(content).digest('hex');
}

export class StorachaAdapter {
  constructor(
    private readonly config: StorachaConfig,
    private readonly logger: MinimalLogger = console,
  ) {}

  buildGatewayUrl(cid: string): string {
    return `${this.config.gatewayBase}/${cid}`;
  }

  async uploadJson(request: StorachaUploadRequest): Promise<StorachaUploadResult> {
    const canonicalPayload = canonicalStringify(request.payload);
    const checksumSha256 = sha256Hex(canonicalPayload);

    if (!this.config.enabled) {
      this.logger.info?.({ kind: request.kind, label: request.label }, 'Storacha disabled, skipping upload');
      return {
        provider: 'storacha',
        archived: false,
        kind: request.kind,
        checksumSha256,
        label: request.label,
        errorCode: 'STORACHA_DISABLED',
        errorMessage: 'Storacha integration is disabled',
      };
    }

    if (!this.config.authToken) {
      return {
        provider: 'storacha',
        archived: false,
        kind: request.kind,
        checksumSha256,
        label: request.label,
        errorCode: 'MISSING_STORACHA_AUTH_TOKEN',
        errorMessage: 'STORACHA_AUTH_TOKEN is required when integration is enabled',
      };
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.config.timeoutMs);

    try {
      const response = await fetch(this.config.uploadUrl, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${this.config.authToken}`,
          'Content-Type': 'application/json',
          'X-Name': request.label,
        },
        body: canonicalPayload,
        signal: controller.signal,
      });

      const body = await response.json().catch(() => ({}));

      if (!response.ok) {
        return {
          provider: 'storacha',
          archived: false,
          kind: request.kind,
          checksumSha256,
          label: request.label,
          errorCode: `HTTP_${response.status}`,
          errorMessage: typeof body?.message === 'string' ? body.message : 'Storacha upload failed',
        };
      }

      const cid = typeof body?.cid === 'string'
        ? body.cid
        : typeof body?.['/'] === 'string'
          ? body['/']
          : undefined;

      if (!cid) {
        return {
          provider: 'storacha',
          archived: false,
          kind: request.kind,
          checksumSha256,
          label: request.label,
          errorCode: 'CID_MISSING_IN_RESPONSE',
          errorMessage: 'Storacha upload response did not include a CID',
        };
      }

      const gatewayUrl = this.buildGatewayUrl(cid);
      return {
        provider: 'storacha',
        archived: true,
        kind: request.kind,
        checksumSha256,
        cid,
        gatewayUrl,
        label: request.label,
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown Storacha upload error';
      this.logger.warn?.({ error: message, kind: request.kind }, 'Storacha upload failed');
      return {
        provider: 'storacha',
        archived: false,
        kind: request.kind,
        checksumSha256,
        label: request.label,
        errorCode: 'STORACHA_REQUEST_FAILED',
        errorMessage: message,
      };
    } finally {
      clearTimeout(timeout);
    }
  }
}
