import type { StorachaConfig } from './storacha.types';

function parseBoolean(value: string | undefined, fallback: boolean): boolean {
  if (value === undefined) return fallback;
  return ['1', 'true', 'yes', 'on'].includes(value.toLowerCase());
}

function parseNumber(value: string | undefined, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

export function getStorachaConfig(env: NodeJS.ProcessEnv): StorachaConfig {
  return {
    enabled: parseBoolean(env.STORACHA_ENABLED, false),
    uploadUrl: env.STORACHA_UPLOAD_URL || 'https://up.storacha.network/upload',
    gatewayBase: (env.STORACHA_GATEWAY_BASE || 'https://storacha.link/ipfs').replace(/\/$/, ''),
    authToken: env.STORACHA_AUTH_TOKEN,
    timeoutMs: parseNumber(env.STORACHA_TIMEOUT_MS, 8000),
    writeCidsOnChain: parseBoolean(env.STORACHA_WRITE_CIDS_ONCHAIN, false),
  };
}
