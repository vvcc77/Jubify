import type { FastifyInstance } from 'fastify';
import { assertUserAccess, requireAuth } from '../../../shared/http/auth-guard';
import { ok } from '../../../shared/http/response';
import { parseWithSchema } from '../../../shared/http/validation';
import { userIdParamsSchema } from '../../plan/plan.schemas';
import { aiDecisionArchiveSchema, livenessArchiveSchema, marketSnapshotArchiveSchema } from './storacha.schemas-extra';

export async function storachaRoutes(app: FastifyInstance): Promise<void> {
  app.get('/storacha/:userId/artifacts', { preHandler: requireAuth }, async (request, reply) => {
    const params = parseWithSchema(userIdParamsSchema, request.params);
    assertUserAccess(request, params.userId);
    const artifacts = app.container.storachaArtifactsService.listArtifacts(params.userId);
    ok(request, reply, { artifacts }, { mode: app.container.env.INTEGRATION_MODE });
  });

  app.post('/storacha/:userId/passport/sync', { preHandler: requireAuth }, async (request, reply) => {
    const params = parseWithSchema(userIdParamsSchema, request.params);
    assertUserAccess(request, params.userId);
    const artifact = await app.container.storachaArtifactsService.archivePassportIfReady(params.userId);
    ok(request, reply, { artifact }, { mode: app.container.env.INTEGRATION_MODE });
  });

  app.post('/storacha/:userId/inheritance/sync', { preHandler: requireAuth }, async (request, reply) => {
    const params = parseWithSchema(userIdParamsSchema, request.params);
    assertUserAccess(request, params.userId);
    const artifact = await app.container.storachaArtifactsService.archiveInheritanceIfReady(params.userId);
    ok(request, reply, { artifact }, { mode: app.container.env.INTEGRATION_MODE });
  });

  app.post('/storacha/:userId/market-snapshot', { preHandler: requireAuth }, async (request, reply) => {
    const params = parseWithSchema(userIdParamsSchema, request.params);
    const body = parseWithSchema(marketSnapshotArchiveSchema, request.body);
    assertUserAccess(request, params.userId);
    const artifact = await app.container.storachaArtifactsService.archiveMarketSnapshot(params.userId, body);
    ok(request, reply, { artifact }, { mode: app.container.env.INTEGRATION_MODE });
  });

  app.post('/storacha/:userId/ai-decision', { preHandler: requireAuth }, async (request, reply) => {
    const params = parseWithSchema(userIdParamsSchema, request.params);
    const body = parseWithSchema(aiDecisionArchiveSchema, request.body);
    assertUserAccess(request, params.userId);
    const artifact = await app.container.storachaArtifactsService.archiveAiDecision(params.userId, body);
    ok(request, reply, { artifact }, { mode: app.container.env.INTEGRATION_MODE });
  });

  app.post('/storacha/:userId/liveness', { preHandler: requireAuth }, async (request, reply) => {
    const params = parseWithSchema(userIdParamsSchema, request.params);
    const body = parseWithSchema(livenessArchiveSchema, request.body);
    assertUserAccess(request, params.userId);
    const artifact = await app.container.storachaArtifactsService.archiveLivenessRecord({
      ...body,
      userRef: params.userId,
    });
    ok(request, reply, { artifact }, { mode: app.container.env.INTEGRATION_MODE });
  });
}
