import { z } from 'zod';
import { aiDecisionSchema, livenessRecordSchema, marketSnapshotSchema } from './storacha.schemas';

export const marketSnapshotArchiveSchema = marketSnapshotSchema;
export const aiDecisionArchiveSchema = aiDecisionSchema;
export const livenessArchiveSchema = livenessRecordSchema.omit({ userRef: true });
