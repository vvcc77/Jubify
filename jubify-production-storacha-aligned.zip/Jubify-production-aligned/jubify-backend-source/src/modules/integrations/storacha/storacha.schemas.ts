import { z } from 'zod';

export const retirementPassportSchema = z.object({
  version: z.string().min(1),
  userRef: z.string().min(1),
  riskTolerance: z.enum(['conservative', 'moderate', 'aggressive']),
  timeHorizonYears: z.number().int().positive(),
  strategyPreference: z.enum(['conservative', 'balanced', 'growth']),
  preferences: z.array(z.string().min(1)).max(20),
  contribution: z.object({
    amount: z.number().positive(),
    frequency: z.enum(['weekly', 'monthly', 'quarterly']),
    currency: z.string().min(1).max(12),
  }),
  retirement: z.object({
    mode: z.enum(['scheduled_income', 'flex_withdrawal', 'deferred_unlock']),
    lockPeriod: z.string().min(2).max(32),
    releaseFrequency: z.enum(['monthly', 'quarterly', 'yearly']),
  }),
  generatedAt: z.string().datetime(),
}).strict();

export const marketCandidateSchema = z.object({
  project: z.string().min(1),
  apy: z.number(),
  tvlUsd: z.number().nonnegative(),
  exposure: z.enum(['single', 'lp', 'basket']),
}).strict();

export const marketSnapshotSchema = z.object({
  version: z.string().min(1),
  chain: z.string().min(1),
  asset: z.string().min(1),
  generatedAt: z.string().datetime(),
  candidates: z.array(marketCandidateSchema).min(1).max(20),
}).strict();

export const aiDecisionSchema = z.object({
  version: z.string().min(1),
  decision: z.enum(['ALLOW', 'WATCH', 'REBALANCE', 'BLOCK']),
  recommendedStrategy: z.enum(['CONSERVATIVE', 'BALANCED', 'GROWTH']),
  recommendedProtocol: z.string().min(0).max(120),
  confidence: z.enum(['low', 'medium', 'high']),
  maxAllocationPct: z.number().int().min(0).max(100),
  reasonShort: z.string().min(1).max(240),
  generatedAt: z.string().datetime(),
}).strict();

export const livenessRecordSchema = z.object({
  version: z.string().min(1),
  userRef: z.string().min(1),
  alive: z.boolean(),
  checkedAt: z.string().datetime(),
  deadlineAt: z.string().datetime().optional(),
  source: z.enum(['backend', 'oracle', 'manual']),
}).strict();

export const inheritanceInstructionSchema = z.object({
  version: z.string().min(1),
  userRef: z.string().min(1),
  mode: z.enum(['sanitized', 'encrypted']),
  beneficiaries: z.array(z.object({
    destination: z.string().min(1),
    percentageBps: z.number().int().min(1).max(10_000),
    alias: z.string().min(1).max(120).optional(),
  }).strict()).min(1).max(10),
  generatedAt: z.string().datetime(),
}).strict().superRefine((value, ctx) => {
  const total = value.beneficiaries.reduce((sum, item) => sum + item.percentageBps, 0);
  if (total !== 10_000) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'beneficiaries percentageBps must sum exactly 10000',
      path: ['beneficiaries'],
    });
  }
});
