import {
  aiDecisionSchema,
  inheritanceInstructionSchema,
  livenessRecordSchema,
  marketSnapshotSchema,
  retirementPassportSchema,
} from './storacha.schemas';
import type {
  AIDecision,
  InheritanceInstruction,
  LivenessRecord,
  MarketSnapshot,
  RetirementPassport,
  StorachaUploadResult,
} from './storacha.types';
import { StorachaAdapter, type MinimalLogger } from './storacha.adapter';

export class StorachaService {
  constructor(
    private readonly adapter: StorachaAdapter,
    private readonly logger: MinimalLogger = console,
  ) {}

  archiveRetirementPassport(input: RetirementPassport): Promise<StorachaUploadResult> {
    const payload = retirementPassportSchema.parse(input);
    return this.adapter.uploadJson({
      kind: 'retirement_passport',
      payload,
      label: `retirement-passport-${payload.userRef}`,
    });
  }

  archiveMarketSnapshot(input: MarketSnapshot): Promise<StorachaUploadResult> {
    const payload = marketSnapshotSchema.parse(input);
    return this.adapter.uploadJson({
      kind: 'market_snapshot',
      payload,
      label: `market-snapshot-${payload.chain.toLowerCase()}-${payload.asset.toLowerCase()}`,
    });
  }

  archiveAiDecision(userRef: string, input: AIDecision): Promise<StorachaUploadResult> {
    const payload = aiDecisionSchema.parse(input);
    return this.adapter.uploadJson({
      kind: 'ai_decision',
      payload: { userRef, ...payload },
      label: `ai-decision-${userRef}`,
    });
  }

  archiveLivenessRecord(input: LivenessRecord): Promise<StorachaUploadResult> {
    const payload = livenessRecordSchema.parse(input);
    return this.adapter.uploadJson({
      kind: 'liveness_record',
      payload,
      label: `liveness-${payload.userRef}`,
    });
  }

  archiveInheritanceInstruction(input: InheritanceInstruction): Promise<StorachaUploadResult> {
    const payload = inheritanceInstructionSchema.parse(input);
    return this.adapter.uploadJson({
      kind: 'inheritance_instruction',
      payload,
      label: `inheritance-${payload.userRef}`,
    });
  }

  async archiveRetirementPassportSafely(input: RetirementPassport): Promise<StorachaUploadResult> {
    try {
      return await this.archiveRetirementPassport(input);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown archive error';
      this.logger.warn?.({ error: message }, 'Retirement passport archive failed');
      return {
        provider: 'storacha',
        archived: false,
        kind: 'retirement_passport',
        checksumSha256: '',
        label: `retirement-passport-${input.userRef}`,
        errorCode: 'RETIREMENT_PASSPORT_ARCHIVE_FAILED',
        errorMessage: message,
      };
    }
  }
}
