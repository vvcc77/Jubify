export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonObject | JsonValue[];

export interface JsonObject {
  [key: string]: JsonValue;
}

export type StorachaArtifactKind =
  | 'retirement_passport'
  | 'market_snapshot'
  | 'ai_decision'
  | 'liveness_record'
  | 'inheritance_instruction';

export interface StorachaConfig {
  enabled: boolean;
  uploadUrl: string;
  gatewayBase: string;
  authToken?: string;
  timeoutMs: number;
  writeCidsOnChain: boolean;
}

export interface StorachaUploadRequest {
  kind: StorachaArtifactKind;
  payload: JsonObject;
  label: string;
}

export interface StorachaUploadResult {
  provider: 'storacha';
  archived: boolean;
  kind: StorachaArtifactKind;
  checksumSha256: string;
  cid?: string;
  gatewayUrl?: string;
  label: string;
  errorCode?: string;
  errorMessage?: string;
}

export interface RetirementPassport extends JsonObject {
  version: string;
  userRef: string;
  riskTolerance: 'conservative' | 'moderate' | 'aggressive';
  timeHorizonYears: number;
  strategyPreference: 'conservative' | 'balanced' | 'growth';
  preferences: string[];
  contribution: {
    amount: number;
    frequency: 'weekly' | 'monthly' | 'quarterly';
    currency: string;
  };
  retirement: {
    mode: 'scheduled_income' | 'flex_withdrawal' | 'deferred_unlock';
    lockPeriod: string;
    releaseFrequency: 'monthly' | 'quarterly' | 'yearly';
  };
  generatedAt: string;
}

export interface MarketSnapshot extends JsonObject {
  version: string;
  chain: string;
  asset: string;
  generatedAt: string;
  candidates: Array<{
    project: string;
    apy: number;
    tvlUsd: number;
    exposure: 'single' | 'lp' | 'basket';
  }>;
}

export interface AIDecision extends JsonObject {
  version: string;
  decision: 'ALLOW' | 'WATCH' | 'REBALANCE' | 'BLOCK';
  recommendedStrategy: 'CONSERVATIVE' | 'BALANCED' | 'GROWTH';
  recommendedProtocol: string;
  confidence: 'low' | 'medium' | 'high';
  maxAllocationPct: number;
  reasonShort: string;
  generatedAt: string;
}

export interface LivenessRecord extends JsonObject {
  version: string;
  userRef: string;
  alive: boolean;
  checkedAt: string;
  deadlineAt?: string;
  source: 'backend' | 'oracle' | 'manual';
}

export interface InheritanceInstruction extends JsonObject {
  version: string;
  userRef: string;
  mode: 'sanitized' | 'encrypted';
  beneficiaries: Array<{
    destination: string;
    percentageBps: number;
    alias?: string;
  }>;
  generatedAt: string;
}
