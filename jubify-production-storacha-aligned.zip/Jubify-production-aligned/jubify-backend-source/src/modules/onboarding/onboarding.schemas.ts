import { z } from 'zod';

export const profileSchema = z.object({
  riskTolerance: z.enum(['conservative', 'moderate', 'aggressive']),
  timeHorizon: z.string().min(2).max(20)
});

export const preferencesSchema = z.object({
  preferences: z.array(z.string().min(1)).max(20)
});
