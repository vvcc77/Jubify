import { PlanRepository, ProfileRepository, ProtectionRepository, RetirementRepository } from '../../infra/memory/repositories';

export class OnboardingService {
  constructor(
    private readonly profileRepo: ProfileRepository,
    private readonly planRepo: PlanRepository,
    private readonly retirementRepo: RetirementRepository,
    private readonly protectionRepo: ProtectionRepository
  ) {}

  getState(userId: string) {
    const completedSteps: string[] = ['auth'];

    const profile = this.profileRepo.findByUserId(userId);
    const plan = this.planRepo.findByUserId(userId);
    const retirement = this.retirementRepo.findByUserId(userId);
    const protection = this.protectionRepo.findByUserId(userId);

    if (profile && profile.riskTolerance && profile.timeHorizon) {
      completedSteps.push('profile');
    }

    if (profile && profile.preferences.length > 0) {
      completedSteps.push('preferences');
    }

    if (plan) {
      completedSteps.push('plan');
    }

    if (retirement) {
      completedSteps.push('retirement');
    }

    if (protection) {
      completedSteps.push('protection');
    }

    const all = ['auth', 'profile', 'preferences', 'plan', 'retirement', 'protection'];
    const pendingSteps = all.filter((step) => !completedSteps.includes(step));

    return {
      completedSteps,
      pendingSteps,
      isComplete: pendingSteps.length === 0
    };
  }
}
