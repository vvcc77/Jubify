import type { RetirementPassport } from '../integrations/storacha/storacha.types';

export interface BuildRetirementPassportInput {
  userRef: string;
  profile: {
    riskTolerance: 'conservative' | 'moderate' | 'aggressive';
    timeHorizonYears: number;
    preferences: string[];
  };
  plan: {
    contributionAmount: number;
    contributionFrequency: 'weekly' | 'monthly' | 'quarterly';
    currency: string;
    strategyType: 'conservative' | 'balanced' | 'growth';
  };
  retirement: {
    mode: 'scheduled_income' | 'flex_withdrawal' | 'deferred_unlock';
    lockPeriod: string;
    releaseFrequency: 'monthly' | 'quarterly' | 'yearly';
  };
  generatedAt?: string;
}

export class RetirementPassportService {
  build(input: BuildRetirementPassportInput): RetirementPassport {
    return {
      version: '1.0',
      userRef: input.userRef,
      riskTolerance: input.profile.riskTolerance,
      timeHorizonYears: input.profile.timeHorizonYears,
      strategyPreference: input.plan.strategyType,
      preferences: [...input.profile.preferences],
      contribution: {
        amount: input.plan.contributionAmount,
        frequency: input.plan.contributionFrequency,
        currency: input.plan.currency,
      },
      retirement: {
        mode: input.retirement.mode,
        lockPeriod: input.retirement.lockPeriod,
        releaseFrequency: input.retirement.releaseFrequency,
      },
      generatedAt: input.generatedAt ?? new Date().toISOString(),
    };
  }
}
