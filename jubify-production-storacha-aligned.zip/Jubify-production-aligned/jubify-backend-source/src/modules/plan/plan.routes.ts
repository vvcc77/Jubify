import type { FastifyInstance } from 'fastify';
import { assertUserAccess, requireAuth } from '../../shared/http/auth-guard';
import { ok } from '../../shared/http/response';
import { parseWithSchema } from '../../shared/http/validation';
import { createPlanSchema, updateContributionSchema, userIdParamsSchema } from './plan.schemas';

export async function planRoutes(app: FastifyInstance): Promise<void> {
  app.post('/plan', { preHandler: requireAuth }, async (request, reply) => {
    const body = parseWithSchema(createPlanSchema, request.body);
    const plan = app.container.planService.create(request.auth!.userId, body);
    void app.container.storachaArtifactsService.archivePassportIfReady(request.auth!.userId).catch((error) => {
      app.log.warn({ error }, 'Storacha passport sync failed after plan update');
    });
    ok(request, reply, { plan }, { mode: app.container.env.INTEGRATION_MODE });
  });

  app.get('/plan/:userId', { preHandler: requireAuth }, async (request, reply) => {
    const params = parseWithSchema(userIdParamsSchema, request.params);
    assertUserAccess(request, params.userId);
    const plan = app.container.planService.getByUserId(params.userId);
    ok(request, reply, { plan }, { mode: app.container.env.INTEGRATION_MODE });
  });

  app.patch('/plan/:userId/contribution', { preHandler: requireAuth }, async (request, reply) => {
    const params = parseWithSchema(userIdParamsSchema, request.params);
    const body = parseWithSchema(updateContributionSchema, request.body);
    assertUserAccess(request, params.userId);
    const plan = app.container.planService.updateContribution(params.userId, body);
    void app.container.storachaArtifactsService.archivePassportIfReady(params.userId).catch((error) => {
      app.log.warn({ error }, 'Storacha passport sync failed after contribution update');
    });
    ok(request, reply, { plan }, { mode: app.container.env.INTEGRATION_MODE });
  });
}
