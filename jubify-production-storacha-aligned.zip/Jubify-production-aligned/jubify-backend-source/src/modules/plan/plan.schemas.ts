import { z } from 'zod';

export const userIdParamsSchema = z.object({
  userId: z.string().min(1)
});

export const createPlanSchema = z.object({
  currency: z.enum(['USD', 'EUR', 'ARS', 'USDC']),
  contributionAmount: z.number().positive(),
  contributionFrequency: z.enum(['weekly', 'monthly', 'quarterly']),
  strategyType: z.enum(['conservative', 'balanced', 'growth'])
});

export const updateContributionSchema = z.object({
  contributionAmount: z.number().positive(),
  contributionFrequency: z.enum(['weekly', 'monthly', 'quarterly'])
});
