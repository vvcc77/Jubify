import type { SavingsPlan } from '../../domain/models';
import { PlanRepository } from '../../infra/memory/repositories';
import { AppError } from '../../shared/errors/app-error';
import { nowIso } from '../../shared/utils/dates';
import { createId } from '../../shared/utils/ids';
import { EventsService } from '../events/events.service';

type CreatePlanInput = Omit<SavingsPlan, 'id' | 'userId' | 'status' | 'createdAt' | 'updatedAt'>;
type UpdateContributionInput = Pick<SavingsPlan, 'contributionAmount' | 'contributionFrequency'>;

export class PlanService {
  constructor(
    private readonly planRepo: PlanRepository,
    private readonly eventsService: EventsService
  ) {}

  create(userId: string, input: CreatePlanInput): SavingsPlan {
    const existing = this.planRepo.findByUserId(userId);
    const now = nowIso();

    const plan: SavingsPlan = {
      id: existing?.id ?? createId('plan'),
      userId,
      status: 'active',
      contributionAmount: input.contributionAmount,
      contributionFrequency: input.contributionFrequency,
      currency: input.currency,
      strategyType: input.strategyType,
      createdAt: existing?.createdAt ?? now,
      updatedAt: now
    };

    this.planRepo.save(plan);
    this.eventsService.record(userId, 'plan_created', {
      contributionAmount: plan.contributionAmount,
      contributionFrequency: plan.contributionFrequency,
      currency: plan.currency,
      strategyType: plan.strategyType
    }, 'ui');

    return plan;
  }

  getByUserId(userId: string): SavingsPlan {
    const plan = this.planRepo.findByUserId(userId);
    if (!plan) {
      throw AppError.notFound('Plan not found');
    }
    return plan;
  }

  updateContribution(userId: string, input: UpdateContributionInput): SavingsPlan {
    const existing = this.getByUserId(userId);

    const updated: SavingsPlan = {
      ...existing,
      contributionAmount: input.contributionAmount,
      contributionFrequency: input.contributionFrequency,
      updatedAt: nowIso()
    };

    this.planRepo.save(updated);
    this.eventsService.record(userId, 'contribution_registered', {
      contributionAmount: updated.contributionAmount,
      contributionFrequency: updated.contributionFrequency
    }, 'ui');

    return updated;
  }
}
