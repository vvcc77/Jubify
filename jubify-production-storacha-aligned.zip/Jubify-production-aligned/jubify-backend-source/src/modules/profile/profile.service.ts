import type { Profile } from '../../domain/models';
import { ProfileRepository } from '../../infra/memory/repositories';
import { nowIso } from '../../shared/utils/dates';
import { EventsService } from '../events/events.service';

export class ProfileService {
  constructor(
    private readonly profileRepo: ProfileRepository,
    private readonly eventsService: EventsService
  ) {}

  saveProfile(userId: string, input: Pick<Profile, 'riskTolerance' | 'timeHorizon'>): Profile {
    const now = nowIso();
    const existing = this.profileRepo.findByUserId(userId);

    const profile: Profile = {
      userId,
      riskTolerance: input.riskTolerance,
      timeHorizon: input.timeHorizon,
      preferences: existing?.preferences ?? [],
      createdAt: existing?.createdAt ?? now,
      updatedAt: now
    };

    this.profileRepo.save(profile);
    this.eventsService.record(userId, 'preference_updated', {
      riskTolerance: profile.riskTolerance,
      timeHorizon: profile.timeHorizon
    }, 'ui');

    return profile;
  }

  savePreferences(userId: string, preferences: string[]): Profile {
    const now = nowIso();
    const existing = this.profileRepo.findByUserId(userId);

    const profile: Profile = {
      userId,
      riskTolerance: existing?.riskTolerance ?? 'moderate',
      timeHorizon: existing?.timeHorizon ?? '10y',
      preferences,
      createdAt: existing?.createdAt ?? now,
      updatedAt: now
    };

    this.profileRepo.save(profile);
    this.eventsService.record(userId, 'preference_updated', { preferences }, 'ui');
    return profile;
  }

  getByUserId(userId: string): Profile | undefined {
    return this.profileRepo.findByUserId(userId);
  }
}
