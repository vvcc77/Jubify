import type { FastifyInstance } from 'fastify';
import { assertUserAccess, requireAuth } from '../../shared/http/auth-guard';
import { ok } from '../../shared/http/response';
import { parseWithSchema } from '../../shared/http/validation';
import { userIdParamsSchema } from '../plan/plan.schemas';
import { inheritanceSchema, protectionSchema } from './protection.schemas';

export async function protectionRoutes(app: FastifyInstance): Promise<void> {
  app.post('/plan/:userId/protection', { preHandler: requireAuth }, async (request, reply) => {
    const params = parseWithSchema(userIdParamsSchema, request.params);
    const body = parseWithSchema(protectionSchema, request.body);
    assertUserAccess(request, params.userId);
    const protection = app.container.protectionService.configureProtection(params.userId, body);
    ok(request, reply, { protection }, { mode: app.container.env.INTEGRATION_MODE });
  });

  app.post('/plan/:userId/inheritance', { preHandler: requireAuth }, async (request, reply) => {
    const params = parseWithSchema(userIdParamsSchema, request.params);
    const body = parseWithSchema(inheritanceSchema, request.body);
    assertUserAccess(request, params.userId);
    const beneficiaries = app.container.protectionService.configureInheritance(params.userId, body.beneficiaries);
    void app.container.storachaArtifactsService.archiveInheritanceIfReady(params.userId).catch((error) => {
      app.log.warn({ error }, 'Storacha inheritance sync failed after inheritance update');
    });
    ok(request, reply, { beneficiaries }, { mode: app.container.env.INTEGRATION_MODE });
  });

  app.get('/plan/:userId/inheritance', { preHandler: requireAuth }, async (request, reply) => {
    const params = parseWithSchema(userIdParamsSchema, request.params);
    assertUserAccess(request, params.userId);
    const inheritance = app.container.protectionService.getInheritance(params.userId);
    ok(request, reply, inheritance, { mode: app.container.env.INTEGRATION_MODE });
  });
}
