import { z } from 'zod';

export const protectionSchema = z.object({
  protectionEnabled: z.boolean(),
  inheritanceEnabled: z.boolean(),
  proofOfLifeInterval: z.string().min(2).max(20)
});

export const inheritanceSchema = z.object({
  beneficiaries: z.array(
    z.object({
      name: z.string().min(1).max(120),
      destinationWalletOrAccount: z.string().min(3).max(255),
      percentage: z.number().positive().max(100)
    })
  ).min(1).max(10)
});
