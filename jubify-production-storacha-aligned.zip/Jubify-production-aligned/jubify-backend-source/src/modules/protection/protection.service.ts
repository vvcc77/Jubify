import type { Beneficiary, ProtectionPlan } from '../../domain/models';
import { BeneficiaryRepository, ProtectionRepository } from '../../infra/memory/repositories';
import { AppError } from '../../shared/errors/app-error';
import { nowIso } from '../../shared/utils/dates';
import { createId } from '../../shared/utils/ids';
import { EventsService } from '../events/events.service';

type ConfigureProtectionInput = Omit<ProtectionPlan, 'userId' | 'createdAt' | 'updatedAt'>;
type ConfigureInheritanceInput = Array<Pick<Beneficiary, 'name' | 'destinationWalletOrAccount' | 'percentage'>>;

export class ProtectionService {
  constructor(
    private readonly protectionRepo: ProtectionRepository,
    private readonly beneficiaryRepo: BeneficiaryRepository,
    private readonly eventsService: EventsService
  ) {}

  configureProtection(userId: string, input: ConfigureProtectionInput): ProtectionPlan {
    const existing = this.protectionRepo.findByUserId(userId);
    const plan: ProtectionPlan = {
      userId,
      protectionEnabled: input.protectionEnabled,
      inheritanceEnabled: input.inheritanceEnabled,
      proofOfLifeInterval: input.proofOfLifeInterval,
      createdAt: existing?.createdAt ?? nowIso(),
      updatedAt: nowIso()
    };

    this.protectionRepo.save(plan);
    this.eventsService.record(userId, 'protection_enabled', {
      protectionEnabled: plan.protectionEnabled,
      inheritanceEnabled: plan.inheritanceEnabled,
      proofOfLifeInterval: plan.proofOfLifeInterval
    }, 'ui');

    this.eventsService.record(userId, 'proof_of_life_updated', {
      proofOfLifeInterval: plan.proofOfLifeInterval
    }, 'ui');

    return plan;
  }

  configureInheritance(userId: string, beneficiaries: ConfigureInheritanceInput): Beneficiary[] {
    const total = beneficiaries.reduce((sum, item) => sum + item.percentage, 0);
    if (total !== 100) {
      throw AppError.badRequest('Beneficiary percentage must total 100');
    }

    const now = nowIso();
    const mapped: Beneficiary[] = beneficiaries.map((item) => ({
      id: createId('bnf'),
      userId,
      name: item.name,
      destinationWalletOrAccount: item.destinationWalletOrAccount,
      percentage: item.percentage,
      createdAt: now,
      updatedAt: now
    }));

    this.beneficiaryRepo.replaceForUser(userId, mapped);
    this.eventsService.record(userId, 'inheritance_updated', {
      beneficiariesCount: mapped.length
    }, 'ui');

    return mapped;
  }

  getProtection(userId: string): ProtectionPlan | undefined {
    return this.protectionRepo.findByUserId(userId);
  }

  getInheritance(userId: string): { protection?: ProtectionPlan; beneficiaries: Beneficiary[] } {
    return {
      protection: this.protectionRepo.findByUserId(userId),
      beneficiaries: this.beneficiaryRepo.findByUserId(userId)
    };
  }
}
