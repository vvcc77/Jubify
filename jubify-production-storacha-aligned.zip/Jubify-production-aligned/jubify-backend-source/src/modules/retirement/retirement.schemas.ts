import { z } from 'zod';

export const retirementSchema = z.object({
  mode: z.enum(['scheduled_income', 'flex_withdrawal', 'deferred_unlock']),
  lockPeriod: z.string().min(2).max(20),
  releaseFrequency: z.enum(['monthly', 'quarterly', 'yearly']),
  estimatedProjection: z.record(z.unknown()).default({})
});
