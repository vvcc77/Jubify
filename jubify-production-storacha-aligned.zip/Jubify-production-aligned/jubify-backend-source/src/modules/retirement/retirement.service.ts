import type { RetirementPlan } from '../../domain/models';
import { RetirementRepository } from '../../infra/memory/repositories';
import { AppError } from '../../shared/errors/app-error';
import { nowIso } from '../../shared/utils/dates';
import { EventsService } from '../events/events.service';

type CreateRetirementInput = Omit<RetirementPlan, 'userId' | 'createdAt' | 'updatedAt'>;

export class RetirementService {
  constructor(
    private readonly retirementRepo: RetirementRepository,
    private readonly eventsService: EventsService
  ) {}

  configure(userId: string, input: CreateRetirementInput): RetirementPlan {
    const existing = this.retirementRepo.findByUserId(userId);
    const plan: RetirementPlan = {
      userId,
      mode: input.mode,
      lockPeriod: input.lockPeriod,
      releaseFrequency: input.releaseFrequency,
      estimatedProjection: input.estimatedProjection,
      createdAt: existing?.createdAt ?? nowIso(),
      updatedAt: nowIso()
    };

    this.retirementRepo.save(plan);
    this.eventsService.record(userId, 'retirement_configured', {
      mode: plan.mode,
      lockPeriod: plan.lockPeriod,
      releaseFrequency: plan.releaseFrequency
    }, 'ui');

    return plan;
  }

  getByUserId(userId: string): RetirementPlan {
    const plan = this.retirementRepo.findByUserId(userId);
    if (!plan) {
      throw AppError.notFound('Retirement plan not found');
    }
    return plan;
  }
}
