import type { FastifyReply, FastifyRequest } from 'fastify';
import { ZodError } from 'zod';
import { AppError } from './app-error';

export function errorHandler(error: Error, request: FastifyRequest, reply: FastifyReply): void {
  if (error instanceof ZodError) {
    reply.status(400).send({
      data: null,
      meta: { requestId: request.id },
      error: {
        code: 'VALIDATION_ERROR',
        message: 'Request validation failed',
        details: error.issues
      }
    });
    return;
  }

  if (error instanceof AppError) {
    reply.status(error.statusCode).send({
      data: null,
      meta: { requestId: request.id },
      error: {
        code: error.code,
        message: error.message,
        details: error.details ?? null
      }
    });
    return;
  }

  request.log.error({ err: error }, 'Unhandled error');

  reply.status(500).send({
    data: null,
    meta: { requestId: request.id },
    error: {
      code: 'INTERNAL_ERROR',
      message: 'Internal server error'
    }
  });
}
