import type { FastifyReply, FastifyRequest } from 'fastify';
import { AppError } from '../errors/app-error';

export type AuthContext = {
  userId: string;
  token: string;
};

export async function requireAuth(request: FastifyRequest, _reply: FastifyReply): Promise<void> {
  const raw = request.headers.authorization;
  if (!raw?.startsWith('Bearer ')) {
    throw AppError.unauthorized('Missing bearer token');
  }

  const token = raw.slice('Bearer '.length).trim();
  const session = request.server.container.authService.verifySession(token);
  request.auth = {
    userId: session.userId,
    token
  };
}

export function assertUserAccess(request: FastifyRequest, userId: string): void {
  if (!request.auth || request.auth.userId !== userId) {
    throw AppError.forbidden('User does not match authenticated session');
  }
}
