import type { FastifyReply, FastifyRequest } from 'fastify';
import { AppError } from '../errors/app-error';

type Bucket = {
  count: number;
  resetAt: number;
};

const buckets = new Map<string, Bucket>();

export function createRateLimit(windowMs: number, max: number) {
  return async function rateLimit(request: FastifyRequest, _reply: FastifyReply): Promise<void> {
    const key = `${request.ip}:${request.routerPath ?? request.url}`;
    const now = Date.now();

    const existing = buckets.get(key);
    if (!existing || now > existing.resetAt) {
      buckets.set(key, {
        count: 1,
        resetAt: now + windowMs
      });
      return;
    }

    existing.count += 1;
    if (existing.count > max) {
      throw new AppError(429, 'RATE_LIMITED', 'Too many requests');
    }
  };
}
