import type { FastifyReply, FastifyRequest } from 'fastify';

export function ok(request: FastifyRequest, reply: FastifyReply, data: unknown, meta: Record<string, unknown> = {}): void {
  reply.send({
    data,
    meta: {
      requestId: request.id,
      ...meta
    },
    error: null
  });
}
