import { ZodTypeAny } from 'zod';

export function parseWithSchema<TSchema extends ZodTypeAny>(schema: TSchema, input: unknown) {
  return schema.parse(input);
}
