import type { ContributionFrequency, ReleaseFrequency } from '../../domain/models';

export function nowIso(): string {
  return new Date().toISOString();
}

export function addHours(dateIso: string, hours: number): string {
  const date = new Date(dateIso);
  date.setHours(date.getHours() + hours);
  return date.toISOString();
}

export function addDays(dateIso: string, days: number): string {
  const date = new Date(dateIso);
  date.setDate(date.getDate() + days);
  return date.toISOString();
}

export function nextContributionAt(baseIso: string, frequency: ContributionFrequency): string {
  switch (frequency) {
    case 'weekly':
      return addDays(baseIso, 7);
    case 'monthly':
      return addDays(baseIso, 30);
    case 'quarterly':
      return addDays(baseIso, 90);
  }
}

export function nextReleaseAt(baseIso: string, frequency: ReleaseFrequency): string {
  switch (frequency) {
    case 'monthly':
      return addDays(baseIso, 30);
    case 'quarterly':
      return addDays(baseIso, 90);
    case 'yearly':
      return addDays(baseIso, 365);
  }
}
