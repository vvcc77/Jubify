import 'fastify';
import type { AppContainer } from '../container';
import type { AuthContext } from '../shared/http/auth-guard';

declare module 'fastify' {
  interface FastifyInstance {
    container: AppContainer;
  }

  interface FastifyRequest {
    auth?: AuthContext;
  }
}
